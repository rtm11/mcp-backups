#!/usr/bin/env python3
"""
Redis MCP Server - Redis operations and caching
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional, Union
from datetime import datetime

import redis
from flask import Flask, jsonify, request

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Redis configuration
REDIS_CONFIG = {
    'host': os.getenv('REDIS_HOST', 'localhost'),
    'port': int(os.getenv('REDIS_PORT', '6379')),
    'password': os.getenv('REDIS_PASSWORD', None),
    'db': int(os.getenv('REDIS_DB', '0'))
}

# Redis client
r = redis.Redis(
    host=REDIS_CONFIG['host'],
    port=REDIS_CONFIG['port'],
    password=REDIS_CONFIG['password'],
    db=REDIS_CONFIG['db'],
    decode_responses=True
)

@app.route('/')
def index():
    return jsonify({'status': 'redis-mcp running'})

@app.route('/health')
def health_check():
    """Health check endpoint"""
    redis_status = "disconnected"
    redis_info = {}
    
    try:
        r.ping()
        redis_status = "connected"
        info = r.info()
        redis_info = {
            "version": info.get("redis_version", "unknown"),
            "mode": info.get("redis_mode", "unknown"),
            "connected_clients": info.get("connected_clients", 0),
            "used_memory": info.get("used_memory_human", "unknown"),
            "total_commands_processed": info.get("total_commands_processed", 0)
        }
    except Exception as e:
        logger.error(f"Redis health check failed: {e}")
        redis_status = "error"
    
    return {
        "status": "healthy" if redis_status == "connected" else "unhealthy",
        "service": "Redis MCP Server",
        "timestamp": datetime.now().isoformat(),
        "redis_status": redis_status,
        "redis_info": redis_info,
        "config": {
            "host": REDIS_CONFIG['host'],
            "port": REDIS_CONFIG['port'],
            "database": REDIS_CONFIG['db']
        }
    }

@app.route('/get/<key>')
def get_key(key):
    """Get a value by key"""
    try:
        value = r.get(key)
        if value is None:
            return jsonify({'error': 'Key not found'}), 404
        
        return jsonify({'key': key, 'value': value})
    
    except Exception as e:
        logger.error(f"Error getting value: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/set', methods=['POST'])
def set_key():
    """Set a key-value pair"""
    data = request.json
    key = data.get('key')
    value = data.get('value')
    ttl = data.get('ttl')

    try:
        if ttl:
            r.setex(key, ttl, value)
        else:
            r.set(key, value)
        
        return jsonify({'status': 'ok', 'key': key, 'value': value})
    
    except Exception as e:
        logger.error(f"Error setting value: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/delete', methods=['POST'])
def delete_keys():
    """Delete one or more keys"""
    data = request.json
    keys = data.get('keys', [])

    try:
        deleted_count = r.delete(*keys)
        return jsonify({'status': 'ok', 'deleted_count': deleted_count})
    
    except Exception as e:
        logger.error(f"Error deleting keys: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/keys')
def list_keys():
    """List keys matching a pattern"""
    pattern = request.args.get('pattern', '*')
    limit = request.args.get('limit', 100)

    try:
        keys = r.keys(pattern)
        if limit:
            keys = keys[:limit]
        
        return jsonify({'keys': keys, 'count': len(keys), 'pattern': pattern})
    
    except Exception as e:
        logger.error(f"Error listing keys: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/exists/<key>')
def key_exists(key):
    """Check if a key exists"""
    try:
        exists = r.exists(key)
        return jsonify({'key': key, 'exists': bool(exists)})
    
    except Exception as e:
        logger.error(f"Error checking key existence: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/ttl/<key>')
def get_ttl(key):
    """Get time to live for a key"""
    try:
        ttl = r.ttl(key)
        return jsonify({'key': key, 'ttl': ttl})
    
    except Exception as e:
        logger.error(f"Error getting TTL: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/expire/<key>', methods=['POST'])
def set_expire(key):
    """Set expiration time for a key"""
    data = request.json
    seconds = data.get('seconds')

    try:
        result = r.expire(key, seconds)
        return jsonify({'key': key, 'expire_set': bool(result)})
    
    except Exception as e:
        logger.error(f"Error setting expiration: {e}")
        return jsonify({'error': str(e)}), 500

# Hash operations
@app.route('/hash/set', methods=['POST'])
def hash_set():
    """Set a hash field"""
    data = request.json
    key = data.get('key')
    field = data.get('field')
    value = data.get('value')

    try:
        r.hset(key, field, value)
        return jsonify({'status': 'ok', 'key': key, 'field': field, 'value': value})
    
    except Exception as e:
        logger.error(f"Error setting hash field: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/hash/get/<key>/<field>')
def hash_get(key, field):
    """Get a hash field value"""
    try:
        value = r.hget(key, field)
        if value is None:
            return jsonify({'error': 'Hash field not found'}), 404
        
        return jsonify({'key': key, 'field': field, 'value': value})
    
    except Exception as e:
        logger.error(f"Error getting hash field: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/hash/getall/<key>')
def hash_get_all(key):
    """Get all hash fields and values"""
    try:
        hash_data = r.hgetall(key)
        if not hash_data:
            return jsonify({'error': 'Hash not found'}), 404
        
        return jsonify({'key': key, 'hash': hash_data})
    
    except Exception as e:
        logger.error(f"Error getting hash: {e}")
        return jsonify({'error': str(e)}), 500

# List operations
@app.route('/list/push', methods=['POST'])
def list_push():
    """Push values to a list"""
    data = request.json
    key = data.get('key')
    values = data.get('values', [])
    direction = data.get('direction', 'left')

    try:
        if direction == "left":
            r.lpush(key, *values)
        else:
            r.rpush(key, *values)
        
        return jsonify({'status': 'ok', 'key': key, 'pushed_values': values})
    
    except Exception as e:
        logger.error(f"Error pushing to list: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/list/range/<key>')
def list_range(key):
    """Get a range of list elements"""
    start = request.args.get('start', 0, type=int)
    end = request.args.get('end', -1, type=int)

    try:
        values = r.lrange(key, start, end)
        return jsonify({'key': key, 'values': values, 'count': len(values)})
    
    except Exception as e:
        logger.error(f"Error getting list range: {e}")
        return jsonify({'error': str(e)}), 500

# Set operations
@app.route('/set/add', methods=['POST'])
def set_add():
    """Add members to a set"""
    data = request.json
    key = data.get('key')
    members = data.get('members', [])

    try:
        r.sadd(key, *members)
        return jsonify({'status': 'ok', 'key': key, 'added_members': members})
    
    except Exception as e:
        logger.error(f"Error adding to set: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/set/members/<key>')
def set_members(key):
    """Get all members of a set"""
    try:
        members = r.smembers(key)
        return jsonify({'key': key, 'members': list(members), 'count': len(members)})
    
    except Exception as e:
        logger.error(f"Error getting set members: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/info')
def get_redis_info():
    """Get Redis server information"""
    try:
        info = r.info()
        return jsonify({
            "server": {
                "version": info.get("redis_version"),
                "mode": info.get("redis_mode"),
                "os": info.get("os"),
                "arch_bits": info.get("arch_bits")
            },
            "clients": {
                "connected_clients": info.get("connected_clients"),
                "client_longest_output_list": info.get("client_longest_output_list")
            },
            "memory": {
                "used_memory": info.get("used_memory"),
                "used_memory_human": info.get("used_memory_human"),
                "used_memory_peak": info.get("used_memory_peak"),
                "used_memory_peak_human": info.get("used_memory_peak_human")
            },
            "stats": {
                "total_connections_received": info.get("total_connections_received"),
                "total_commands_processed": info.get("total_commands_processed"),
                "keyspace_hits": info.get("keyspace_hits"),
                "keyspace_misses": info.get("keyspace_misses")
            }
        })
    
    except Exception as e:
        logger.error(f"Error getting Redis info: {e}")
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000)