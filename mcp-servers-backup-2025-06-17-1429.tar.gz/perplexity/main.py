#!/usr/bin/env python3
"""
Perplexity MCP Server
Integrates Perplexity AI with the centralized memory database
"""

import asyncio
import json
import os
import logging
from typing import Any, Dict, List, Optional

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
PERPLEXITY_API_KEY = os.getenv("PERPLEXITY_API_KEY", "")
MEMORY_SERVER_URL = os.getenv("MEMORY_SERVER_URL", "http://memory-server:8080")
PERPLEXITY_MODEL = os.getenv("PERPLEXITY_MODEL", "llama-3.1-sonar-small-128k-online")

app = FastAPI(title="Perplexity MCP Server", version="1.0.0")

class PerplexityRequest(BaseModel):
    messages: List[Dict[str, str]]
    context_id: Optional[str] = None
    max_tokens: Optional[int] = 4096
    temperature: Optional[float] = 0.2
    top_p: Optional[float] = 0.9

class PerplexityResponse(BaseModel):
    response: str
    context_id: str
    tokens_used: int

class PerplexityServer:
    def __init__(self):
        self.headers = {
            "Authorization": f"Bearer {PERPLEXITY_API_KEY}",
            "Content-Type": "application/json",
        }
        self.perplexity_url = "https://api.perplexity.ai/chat/completions"

    async def store_context(self, context_id: str, data: Dict[str, Any]) -> None:
        """Store conversation context in memory server"""
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{MEMORY_SERVER_URL}/store",
                    json={"context_id": context_id, "data": data},
                    timeout=10.0
                )
        except Exception as e:
            logger.error(f"Failed to store context: {e}")

    async def get_context(self, context_id: str) -> Dict[str, Any]:
        """Retrieve conversation context from memory server"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{MEMORY_SERVER_URL}/retrieve/{context_id}",
                    timeout=10.0
                )
                if response.status_code == 200:
                    return response.json()
                return {}
        except Exception as e:
            logger.error(f"Failed to retrieve context: {e}")
            return {}

    async def chat_completion(self, request: PerplexityRequest) -> PerplexityResponse:
        """Send chat completion request to Perplexity AI"""
        if not PERPLEXITY_API_KEY or PERPLEXITY_API_KEY == "your_perplexity_api_key_here":
            raise HTTPException(
                status_code=400, 
                detail="Perplexity API key not configured"
            )

        # Get conversation history if context_id provided
        conversation_history = []
        if request.context_id:
            context_data = await self.get_context(request.context_id)
            conversation_history = context_data.get("messages", [])

        # Combine history with new messages
        all_messages = conversation_history + request.messages

        # Prepare the request payload
        payload = {
            "model": PERPLEXITY_MODEL,
            "messages": all_messages,
            "max_tokens": request.max_tokens,
            "temperature": request.temperature,
            "top_p": request.top_p,
            "stream": False
        }

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.perplexity_url,
                    headers=self.headers,
                    json=payload,
                    timeout=60.0
                )

                if response.status_code != 200:
                    logger.error(f"Perplexity API error: {response.status_code} - {response.text}")
                    raise HTTPException(
                        status_code=response.status_code,
                        detail=f"Perplexity API error: {response.text}"
                    )

                result = response.json()
                
                # Extract response
                ai_response = result["choices"][0]["message"]["content"]
                tokens_used = result.get("usage", {}).get("total_tokens", 0)

                # Store updated conversation in memory
                if request.context_id:
                    updated_messages = all_messages + [{"role": "assistant", "content": ai_response}]
                    await self.store_context(request.context_id, {
                        "messages": updated_messages[-20:],  # Keep last 20 messages
                        "model": PERPLEXITY_MODEL,
                        "total_tokens": tokens_used
                    })

                return PerplexityResponse(
                    response=ai_response,
                    context_id=request.context_id or "no_context",
                    tokens_used=tokens_used
                )

        except httpx.TimeoutException:
            raise HTTPException(status_code=408, detail="Request timeout")
        except Exception as e:
            logger.error(f"Error calling Perplexity API: {e}")
            raise HTTPException(status_code=500, detail=str(e))

# Initialize server
perplexity_server = PerplexityServer()

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "memory_server": MEMORY_SERVER_URL,
        "model": PERPLEXITY_MODEL
    }

@app.post("/chat", response_model=PerplexityResponse)
async def chat_completion(request: PerplexityRequest):
    """Chat completion endpoint"""
    return await perplexity_server.chat_completion(request)

@app.get("/status")
async def get_status():
    """Get server status"""
    return {
        "server": "Perplexity MCP Server",
        "model": PERPLEXITY_MODEL,
        "memory_server": MEMORY_SERVER_URL,
        "api_key_configured": bool(PERPLEXITY_API_KEY and PERPLEXITY_API_KEY != "your_perplexity_api_key_here")
    }

@app.get("/models")
async def list_models():
    """List available Perplexity models"""
    return {
        "models": [
            "llama-3.1-sonar-small-128k-online",
            "llama-3.1-sonar-large-128k-online",
            "llama-3.1-sonar-huge-128k-online",
            "llama-3.1-8b-instruct",
            "llama-3.1-70b-instruct"
        ],
        "current_model": PERPLEXITY_MODEL
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
