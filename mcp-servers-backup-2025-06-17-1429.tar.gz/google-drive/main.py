#!/usr/bin/env python3
"""
Google Drive MCP Server - Google Drive operations
"""

import os
import json
import logging
import io
from typing import List, Dict, Any, Optional
from datetime import datetime

from fastapi import FastAPI, HTTPException, UploadFile, File
from pydantic import BaseModel, Field
from googleapiclient.discovery import build
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.http import MediaIoBaseDownload, MediaIoBaseUpload

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Google Drive MCP Server", version="1.0.0")

# Configuration
SCOPES = ['https://www.googleapis.com/auth/drive']
CREDENTIALS_FILE = os.getenv('GOOGLE_CREDENTIALS_FILE', 'credentials.json')
TOKEN_FILE = 'token.json'
MAX_FILE_SIZE = int(os.getenv('MAX_FILE_SIZE', '52428800'))  # 50MB default
FOLDER_ID = os.getenv('GOOGLE_DRIVE_FOLDER_ID')

# Google Drive service
drive_service = None

class FileInfo(BaseModel):
    id: str
    name: str
    mimeType: str
    size: Optional[str] = None
    createdTime: datetime
    modifiedTime: datetime
    parents: Optional[List[str]] = None
    webViewLink: Optional[str] = None

class UploadRequest(BaseModel):
    name: str
    content: str
    mimeType: str = "text/plain"
    parentId: Optional[str] = None

class ShareRequest(BaseModel):
    fileId: str
    email: Optional[str] = None
    role: str = Field(default="reader", description="reader, writer, or owner")
    type: str = Field(default="user", description="user, group, domain, or anyone")

def authenticate_google_drive():
    """Authenticate with Google Drive API"""
    global drive_service
    
    creds = None
    # Load existing token
    if os.path.exists(TOKEN_FILE):
        creds = Credentials.from_authorized_user_file(TOKEN_FILE, SCOPES)
    
    # If no valid credentials, authenticate
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not os.path.exists(CREDENTIALS_FILE):
                logger.error(f"Credentials file not found: {CREDENTIALS_FILE}")
                return False
            
            flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_FILE, SCOPES)
            creds = flow.run_local_server(port=0)
        
        # Save credentials for next run
        with open(TOKEN_FILE, 'w') as token:
            token.write(creds.to_json())
    
    try:
        drive_service = build('drive', 'v3', credentials=creds)
        logger.info("Google Drive service initialized")
        return True
    except Exception as e:
        logger.error(f"Failed to initialize Google Drive service: {e}")
        return False

@app.on_event("startup")
async def startup_event():
    authenticate_google_drive()

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    service_status = "connected" if drive_service else "disconnected"
    
    service_info = {}
    if drive_service:
        try:
            about = drive_service.about().get(fields="user,storageQuota").execute()
            service_info = {
                "user_email": about.get("user", {}).get("emailAddress"),
                "user_name": about.get("user", {}).get("displayName"),
                "storage_limit": about.get("storageQuota", {}).get("limit"),
                "storage_usage": about.get("storageQuota", {}).get("usage")
            }
        except Exception as e:
            logger.error(f"Error getting Drive info: {e}")
    
    return {
        "status": "healthy" if service_status == "connected" else "unhealthy",
        "service": "Google Drive MCP Server",
        "timestamp": datetime.now().isoformat(),
        "service_status": service_status,
        "service_info": service_info,
        "credentials_configured": os.path.exists(CREDENTIALS_FILE),
        "max_file_size": MAX_FILE_SIZE
    }

@app.get("/files", response_model=List[FileInfo])
async def list_files(folder_id: Optional[str] = None, limit: int = 100):
    """List files in Google Drive"""
    if not drive_service:
        raise HTTPException(status_code=503, detail="Google Drive service not available")
    
    try:
        query = ""
        if folder_id or FOLDER_ID:
            query = f"'{folder_id or FOLDER_ID}' in parents"
        
        results = drive_service.files().list(
            q=query,
            pageSize=limit,
            fields="files(id,name,mimeType,size,createdTime,modifiedTime,parents,webViewLink)"
        ).execute()
        
        files = results.get('files', [])
        
        file_list = []
        for file in files:
            file_info = FileInfo(
                id=file['id'],
                name=file['name'],
                mimeType=file['mimeType'],
                size=file.get('size'),
                createdTime=datetime.fromisoformat(file['createdTime'].replace('Z', '+00:00')),
                modifiedTime=datetime.fromisoformat(file['modifiedTime'].replace('Z', '+00:00')),
                parents=file.get('parents'),
                webViewLink=file.get('webViewLink')
            )
            file_list.append(file_info)
        
        return file_list
    
    except Exception as e:
        logger.error(f"Error listing files: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/files/{file_id}")
async def get_file_info(file_id: str):
    """Get detailed file information"""
    if not drive_service:
        raise HTTPException(status_code=503, detail="Google Drive service not available")
    
    try:
        file = drive_service.files().get(
            fileId=file_id,
            fields="id,name,mimeType,size,createdTime,modifiedTime,parents,webViewLink,description,owners"
        ).execute()
        
        return {
            "id": file['id'],
            "name": file['name'],
            "mimeType": file['mimeType'],
            "size": file.get('size'),
            "createdTime": file['createdTime'],
            "modifiedTime": file['modifiedTime'],
            "parents": file.get('parents'),
            "webViewLink": file.get('webViewLink'),
            "description": file.get('description'),
            "owners": file.get('owners')
        }
    
    except Exception as e:
        logger.error(f"Error getting file info: {e}")
        if "File not found" in str(e):
            raise HTTPException(status_code=404, detail="File not found")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/files/{file_id}/content")
async def download_file(file_id: str):
    """Download file content"""
    if not drive_service:
        raise HTTPException(status_code=503, detail="Google Drive service not available")
    
    try:
        # Get file metadata first
        file = drive_service.files().get(fileId=file_id).execute()
        
        # Download file content
        request = drive_service.files().get_media(fileId=file_id)
        file_io = io.BytesIO()
        downloader = MediaIoBaseDownload(file_io, request)
        
        done = False
        while done is False:
            status, done = downloader.next_chunk()
        
        file_io.seek(0)
        content = file_io.read()
        
        # Try to decode as text if possible
        try:
            text_content = content.decode('utf-8')
            return {
                "file_id": file_id,
                "name": file['name'],
                "content": text_content,
                "content_type": "text",
                "size": len(content)
            }
        except UnicodeDecodeError:
            # Return base64 encoded content for binary files
            import base64
            return {
                "file_id": file_id,
                "name": file['name'],
                "content": base64.b64encode(content).decode('utf-8'),
                "content_type": "binary",
                "size": len(content)
            }
    
    except Exception as e:
        logger.error(f"Error downloading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/files/upload")
async def upload_file(request: UploadRequest):
    """Upload a file to Google Drive"""
    if not drive_service:
        raise HTTPException(status_code=503, detail="Google Drive service not available")
    
    try:
        # Prepare file metadata
        file_metadata = {
            'name': request.name
        }
        
        parent_id = request.parentId or FOLDER_ID
        if parent_id:
            file_metadata['parents'] = [parent_id]
        
        # Create media upload
        media = MediaIoBaseUpload(
            io.BytesIO(request.content.encode('utf-8')),
            mimetype=request.mimeType
        )
        
        # Upload file
        file = drive_service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id,name,webViewLink'
        ).execute()
        
        return {
            "message": "File uploaded successfully",
            "file_id": file['id'],
            "name": file['name'],
            "webViewLink": file.get('webViewLink')
        }
    
    except Exception as e:
        logger.error(f"Error uploading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.put("/files/{file_id}")
async def update_file(file_id: str, content: str):
    """Update file content"""
    if not drive_service:
        raise HTTPException(status_code=503, detail="Google Drive service not available")
    
    try:
        # Create media upload
        media = MediaIoBaseUpload(
            io.BytesIO(content.encode('utf-8')),
            mimetype='text/plain'
        )
        
        # Update file
        file = drive_service.files().update(
            fileId=file_id,
            media_body=media,
            fields='id,name,modifiedTime'
        ).execute()
        
        return {
            "message": "File updated successfully",
            "file_id": file['id'],
            "name": file['name'],
            "modifiedTime": file['modifiedTime']
        }
    
    except Exception as e:
        logger.error(f"Error updating file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/files/{file_id}")
async def delete_file(file_id: str):
    """Delete a file"""
    if not drive_service:
        raise HTTPException(status_code=503, detail="Google Drive service not available")
    
    try:
        drive_service.files().delete(fileId=file_id).execute()
        return {"message": f"File {file_id} deleted successfully"}
    
    except Exception as e:
        logger.error(f"Error deleting file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/files/{file_id}/share")
async def share_file(file_id: str, request: ShareRequest):
    """Share a file with permissions"""
    if not drive_service:
        raise HTTPException(status_code=503, detail="Google Drive service not available")
    
    try:
        permission = {
            'type': request.type,
            'role': request.role
        }
        
        if request.email and request.type == 'user':
            permission['emailAddress'] = request.email
        
        drive_service.permissions().create(
            fileId=file_id,
            body=permission,
            sendNotificationEmail=True
        ).execute()
        
        return {"message": f"File shared successfully with {request.role} permissions"}
    
    except Exception as e:
        logger.error(f"Error sharing file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/search")
async def search_files(query: str, limit: int = 50):
    """Search for files"""
    if not drive_service:
        raise HTTPException(status_code=503, detail="Google Drive service not available")
    
    try:
        search_query = f"name contains '{query}'"
        
        results = drive_service.files().list(
            q=search_query,
            pageSize=limit,
            fields="files(id,name,mimeType,modifiedTime,webViewLink)"
        ).execute()
        
        files = results.get('files', [])
        return {"query": query, "files": files, "count": len(files)}
    
    except Exception as e:
        logger.error(f"Error searching files: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/folders")
async def create_folder(name: str, parent_id: Optional[str] = None):
    """Create a new folder"""
    if not drive_service:
        raise HTTPException(status_code=503, detail="Google Drive service not available")
    
    try:
        file_metadata = {
            'name': name,
            'mimeType': 'application/vnd.google-apps.folder'
        }
        
        if parent_id or FOLDER_ID:
            file_metadata['parents'] = [parent_id or FOLDER_ID]
        
        folder = drive_service.files().create(
            body=file_metadata,
            fields='id,name,webViewLink'
        ).execute()
        
        return {
            "message": "Folder created successfully",
            "folder_id": folder['id'],
            "name": folder['name'],
            "webViewLink": folder.get('webViewLink')
        }
    
    except Exception as e:
        logger.error(f"Error creating folder: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# MCP Protocol implementation
@app.post("/mcp/tools/call")
async def mcp_tool_call(request: Dict[str, Any]):
    """MCP tool call handler"""
    try:
        tool_name = request.get("name")
        arguments = request.get("arguments", {})
        
        if tool_name == "list_files":
            folder_id = arguments.get("folder_id")
            limit = arguments.get("limit", 100)
            files = await list_files(folder_id, limit)
            return {"result": {"files": [f.dict() for f in files]}}
        
        elif tool_name == "get_file_info":
            file_id = arguments.get("file_id")
            info = await get_file_info(file_id)
            return {"result": info}
        
        elif tool_name == "download_file":
            file_id = arguments.get("file_id")
            content = await download_file(file_id)
            return {"result": content}
        
        elif tool_name == "upload_file":
            upload_req = UploadRequest(**arguments)
            result = await upload_file(upload_req)
            return {"result": result}
        
        elif tool_name == "search_files":
            query = arguments.get("query")
            limit = arguments.get("limit", 50)
            results = await search_files(query, limit)
            return {"result": results}
        
        elif tool_name == "create_folder":
            name = arguments.get("name")
            parent_id = arguments.get("parent_id")
            result = await create_folder(name, parent_id)
            return {"result": result}
        
        else:
            raise HTTPException(status_code=400, detail=f"Unknown tool: {tool_name}")
    
    except Exception as e:
        logger.error(f"MCP tool call error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/mcp/tools")
async def mcp_tools():
    """Get available MCP tools"""
    tools = [
        {
            "name": "list_files",
            "description": "List files in Google Drive",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "folder_id": {"type": "string", "description": "Folder ID to list files from"},
                    "limit": {"type": "integer", "description": "Maximum number of files"}
                }
            }
        },
        {
            "name": "get_file_info",
            "description": "Get detailed information about a file",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "file_id": {"type": "string", "description": "Google Drive file ID"}
                },
                "required": ["file_id"]
            }
        },
        {
            "name": "download_file",
            "description": "Download file content from Google Drive",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "file_id": {"type": "string", "description": "Google Drive file ID"}
                },
                "required": ["file_id"]
            }
        },
        {
            "name": "upload_file",
            "description": "Upload a file to Google Drive",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "File name"},
                    "content": {"type": "string", "description": "File content"},
                    "mimeType": {"type": "string", "description": "MIME type"},
                    "parentId": {"type": "string", "description": "Parent folder ID"}
                },
                "required": ["name", "content"]
            }
        },
        {
            "name": "search_files",
            "description": "Search for files in Google Drive",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"},
                    "limit": {"type": "integer", "description": "Maximum number of results"}
                },
                "required": ["query"]
            }
        },
        {
            "name": "create_folder",
            "description": "Create a new folder in Google Drive",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Folder name"},
                    "parent_id": {"type": "string", "description": "Parent folder ID"}
                },
                "required": ["name"]
            }
        }
    ]
    return {"tools": tools}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000, log_level="info")