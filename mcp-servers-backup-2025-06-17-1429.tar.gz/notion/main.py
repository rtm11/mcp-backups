#!/usr/bin/env python3
"""
Notion MCP Server
Integrates Notion API with the centralized memory database
"""

import asyncio
import json
import os
import logging
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from notion_client import Client
from notion_client.errors import APIResponseError

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
NOTION_API_KEY = os.getenv("NOTION_API_KEY", "")
MEMORY_SERVER_URL = os.getenv("MEMORY_SERVER_URL", "http://memory-server:8080")
NOTION_VERSION = os.getenv("NOTION_VERSION", "2022-06-28")

app = FastAPI(title="Notion MCP Server", version="1.0.0")

class NotionQueryRequest(BaseModel):
    query: str
    context_id: Optional[str] = None
    database_id: Optional[str] = None
    page_id: Optional[str] = None

class NotionCreateRequest(BaseModel):
    parent_id: str
    title: str
    content: Optional[Dict[str, Any]] = None
    properties: Optional[Dict[str, Any]] = None
    context_id: Optional[str] = None

class NotionUpdateRequest(BaseModel):
    page_id: str
    properties: Optional[Dict[str, Any]] = None
    content: Optional[Dict[str, Any]] = None
    context_id: Optional[str] = None

class NotionResponse(BaseModel):
    results: List[Dict[str, Any]]
    context_id: str
    operation: str
    success: bool

class NotionServer:
    def __init__(self):
        if not NOTION_API_KEY or NOTION_API_KEY == "your_notion_api_key_here":
            logger.warning("No valid Notion API key provided")
            self.client = None
        else:
            self.client = Client(auth=NOTION_API_KEY, notion_version=NOTION_VERSION)

    async def store_context(self, context_id: str, data: Dict[str, Any]) -> None:
        """Store operation context in memory server"""
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{MEMORY_SERVER_URL}/store",
                    json={
                        "context_id": context_id,
                        "data": data,
                        "ttl": 3600  # 1 hour TTL
                    }
                )
        except Exception as e:
            logger.error(f"Failed to store context: {e}")

    async def retrieve_context(self, context_id: str) -> Dict[str, Any]:
        """Retrieve operation context from memory server"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{MEMORY_SERVER_URL}/retrieve/{context_id}"
                )
                if response.status_code == 200:
                    return response.json().get("data", {})
        except Exception as e:
            logger.error(f"Failed to retrieve context: {e}")
        return {}

    async def search_pages(self, query: str, context_id: str) -> Dict[str, Any]:
        """Search for pages in Notion"""
        if not self.client:
            raise HTTPException(status_code=500, detail="Notion API not configured")

        try:
            # Search for pages
            search_results = self.client.search(
                query=query,
                filter={"property": "object", "value": "page"}
            )

            results = []
            for page in search_results.get("results", []):
                page_info = {
                    "id": page["id"],
                    "title": self._extract_title(page),
                    "url": page.get("url", ""),
                    "created_time": page.get("created_time", ""),
                    "last_edited_time": page.get("last_edited_time", ""),
                    "properties": page.get("properties", {})
                }
                results.append(page_info)

            # Store in memory for context
            operation_data = {
                "operation": "search_pages",
                "query": query,
                "results": results,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            await self.store_context(context_id, operation_data)

            return {
                "results": results,
                "context_id": context_id,
                "operation": "search_pages",
                "success": True
            }

        except APIResponseError as e:
            logger.error(f"Notion API error: {e}")
            raise HTTPException(status_code=400, detail=f"Notion API error: {e}")
        except Exception as e:
            logger.error(f"Search error: {e}")
            raise HTTPException(status_code=500, detail=f"Search failed: {e}")

    async def query_database(self, database_id: str, context_id: str, 
                           filter_conditions: Optional[Dict] = None) -> Dict[str, Any]:
        """Query a Notion database"""
        if not self.client:
            raise HTTPException(status_code=500, detail="Notion API not configured")

        try:
            query_payload = {}
            if filter_conditions:
                query_payload["filter"] = filter_conditions

            response = self.client.databases.query(
                database_id=database_id,
                **query_payload
            )

            results = []
            for page in response.get("results", []):
                page_info = {
                    "id": page["id"],
                    "properties": page.get("properties", {}),
                    "url": page.get("url", ""),
                    "created_time": page.get("created_time", ""),
                    "last_edited_time": page.get("last_edited_time", "")
                }
                results.append(page_info)

            # Store in memory for context
            operation_data = {
                "operation": "query_database",
                "database_id": database_id,
                "filter": filter_conditions,
                "results": results,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            await self.store_context(context_id, operation_data)

            return {
                "results": results,
                "context_id": context_id,
                "operation": "query_database",
                "success": True
            }

        except APIResponseError as e:
            logger.error(f"Notion API error: {e}")
            raise HTTPException(status_code=400, detail=f"Notion API error: {e}")
        except Exception as e:
            logger.error(f"Database query error: {e}")
            raise HTTPException(status_code=500, detail=f"Database query failed: {e}")

    async def create_page(self, parent_id: str, title: str, content: Optional[Dict] = None,
                         properties: Optional[Dict] = None, context_id: str = None) -> Dict[str, Any]:
        """Create a new page in Notion"""
        if not self.client:
            raise HTTPException(status_code=500, detail="Notion API not configured")

        try:
            # Prepare page data
            page_data = {
                "parent": {"page_id": parent_id} if len(parent_id) == 32 else {"database_id": parent_id},
                "properties": {
                    "title": {
                        "title": [{"type": "text", "text": {"content": title}}]
                    }
                }
            }

            # Add custom properties if provided
            if properties:
                page_data["properties"].update(properties)

            # Add content if provided
            if content:
                page_data["children"] = content.get("children", [])

            response = self.client.pages.create(**page_data)

            # Store in memory for context
            operation_data = {
                "operation": "create_page",
                "parent_id": parent_id,
                "title": title,
                "page_id": response["id"],
                "url": response.get("url", ""),
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            await self.store_context(context_id, operation_data)

            return {
                "results": [response],
                "context_id": context_id,
                "operation": "create_page",
                "success": True
            }

        except APIResponseError as e:
            logger.error(f"Notion API error: {e}")
            raise HTTPException(status_code=400, detail=f"Notion API error: {e}")
        except Exception as e:
            logger.error(f"Page creation error: {e}")
            raise HTTPException(status_code=500, detail=f"Page creation failed: {e}")

    async def update_page(self, page_id: str, properties: Optional[Dict] = None,
                         context_id: str = None) -> Dict[str, Any]:
        """Update an existing page in Notion"""
        if not self.client:
            raise HTTPException(status_code=500, detail="Notion API not configured")

        try:
            update_data = {}
            if properties:
                update_data["properties"] = properties

            response = self.client.pages.update(page_id=page_id, **update_data)

            # Store in memory for context
            operation_data = {
                "operation": "update_page",
                "page_id": page_id,
                "properties": properties,
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            await self.store_context(context_id, operation_data)

            return {
                "results": [response],
                "context_id": context_id,
                "operation": "update_page",
                "success": True
            }

        except APIResponseError as e:
            logger.error(f"Notion API error: {e}")
            raise HTTPException(status_code=400, detail=f"Notion API error: {e}")
        except Exception as e:
            logger.error(f"Page update error: {e}")
            raise HTTPException(status_code=500, detail=f"Page update failed: {e}")

    async def get_page_content(self, page_id: str, context_id: str) -> Dict[str, Any]:
        """Get page content including blocks"""
        if not self.client:
            raise HTTPException(status_code=500, detail="Notion API not configured")

        try:
            # Get page properties
            page = self.client.pages.retrieve(page_id=page_id)
            
            # Get page blocks (content)
            blocks = self.client.blocks.children.list(block_id=page_id)

            result = {
                "page": page,
                "blocks": blocks.get("results", [])
            }

            # Store in memory for context
            operation_data = {
                "operation": "get_page_content",
                "page_id": page_id,
                "title": self._extract_title(page),
                "blocks_count": len(blocks.get("results", [])),
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
            await self.store_context(context_id, operation_data)

            return {
                "results": [result],
                "context_id": context_id,
                "operation": "get_page_content",
                "success": True
            }

        except APIResponseError as e:
            logger.error(f"Notion API error: {e}")
            raise HTTPException(status_code=400, detail=f"Notion API error: {e}")
        except Exception as e:
            logger.error(f"Get page content error: {e}")
            raise HTTPException(status_code=500, detail=f"Get page content failed: {e}")

    def _extract_title(self, page: Dict[str, Any]) -> str:
        """Extract title from page properties"""
        properties = page.get("properties", {})
        for prop_name, prop_value in properties.items():
            if prop_value.get("type") == "title":
                title_array = prop_value.get("title", [])
                if title_array:
                    return title_array[0].get("text", {}).get("content", "Untitled")
        return "Untitled"

# Initialize server
notion_server = NotionServer()

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "memory_server": MEMORY_SERVER_URL,
        "notion_configured": notion_server.client is not None
    }

@app.post("/search", response_model=NotionResponse)
async def search_pages(request: NotionQueryRequest):
    """Search for pages in Notion"""
    context_id = request.context_id or f"notion_search_{datetime.now().timestamp()}"
    return await notion_server.search_pages(request.query, context_id)

@app.post("/database/query", response_model=NotionResponse)
async def query_database(request: NotionQueryRequest):
    """Query a Notion database"""
    if not request.database_id:
        raise HTTPException(status_code=400, detail="database_id is required")
    
    context_id = request.context_id or f"notion_db_query_{datetime.now().timestamp()}"
    return await notion_server.query_database(request.database_id, context_id)

@app.post("/page/create", response_model=NotionResponse)
async def create_page(request: NotionCreateRequest):
    """Create a new page in Notion"""
    context_id = request.context_id or f"notion_create_{datetime.now().timestamp()}"
    return await notion_server.create_page(
        request.parent_id, 
        request.title, 
        request.content, 
        request.properties, 
        context_id
    )

@app.post("/page/update", response_model=NotionResponse)
async def update_page(request: NotionUpdateRequest):
    """Update an existing page in Notion"""
    context_id = request.context_id or f"notion_update_{datetime.now().timestamp()}"
    return await notion_server.update_page(
        request.page_id, 
        request.properties, 
        context_id
    )

@app.get("/page/{page_id}/content", response_model=NotionResponse)
async def get_page_content(page_id: str, context_id: Optional[str] = None):
    """Get page content including blocks"""
    context_id = context_id or f"notion_content_{datetime.now().timestamp()}"
    return await notion_server.get_page_content(page_id, context_id)

@app.get("/context/{context_id}")
async def get_context(context_id: str):
    """Retrieve operation context from memory"""
    context_data = await notion_server.retrieve_context(context_id)
    if not context_data:
        raise HTTPException(status_code=404, detail="Context not found")
    return context_data

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
