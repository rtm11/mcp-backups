#!/usr/bin/env python3
"""
ChatGPT MCP Server
Integrates OpenAI's ChatGPT with the centralized memory database
"""

import asyncio
import json
import os
import logging
import time
from typing import Any, Dict, List, Optional

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
MEMORY_SERVER_URL = os.getenv("MEMORY_SERVER_URL", "http://memory-server:8080")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4")

app = FastAPI(title="ChatGPT MCP Server", version="1.0.0")

class ChatGPTRequest(BaseModel):
    messages: List[Dict[str, str]]
    context_id: Optional[str] = None
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = 4096

class ChatGPTResponse(BaseModel):
    response: str
    context_id: str
    tokens_used: int

class ChatGPTServer:
    def __init__(self):
        self.headers = {
            "Authorization": f"Bearer {OPENAI_API_KEY}",
            "Content-Type": "application/json"
        }
        self.openai_url = "https://api.openai.com/v1/chat/completions"

    async def store_context(self, context_id: str, data: Dict[str, Any]) -> None:
        """Store conversation context in memory server"""
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{MEMORY_SERVER_URL}/memory/store",
                    json={
                        "key": f"chatgpt_context_{context_id}",
                        "value": data,
                        "ttl": 3600  # 1 hour
                    }
                )
        except Exception as e:
            logger.warning(f"Failed to store context: {e}")

    async def retrieve_context(self, context_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve conversation context from memory server - check all AI services"""
        try:
            # Try to retrieve from multiple sources (cross-AI memory)
            sources = ["claude_context_", "chatgpt_context_", "gemini_context_", "grok_context_", "perplexity_context_"]
            
            async with httpx.AsyncClient() as client:
                for source in sources:
                    try:
                        response = await client.get(
                            f"{MEMORY_SERVER_URL}/memory/retrieve/{source}{context_id}"
                        )
                        if response.status_code == 200:
                            return response.json().get("data", {}).get("value")
                    except:
                        continue
        except Exception as e:
            logger.warning(f"Failed to retrieve context: {e}")
        return None

    async def chat_completion(self, request: ChatGPTRequest) -> ChatGPTResponse:
        """Send request to ChatGPT and manage context"""
        try:
            # Retrieve existing context if provided
            context_data = None
            if request.context_id:
                context_data = await self.retrieve_context(request.context_id)
            
            # Prepare messages with context
            messages = request.messages.copy()
            
            # Add context to conversation if available
            if context_data and "messages" in context_data:
                # Prepend previous messages for continuity
                previous_messages = context_data["messages"][-10:]  # Last 10 messages
                messages = previous_messages + messages

            # Prepare OpenAI API request
            openai_request = {
                "model": OPENAI_MODEL,
                "messages": messages,
                "temperature": request.temperature,
                "max_tokens": request.max_tokens
            }

            # Call OpenAI API
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.openai_url,
                    headers=self.headers,
                    json=openai_request,
                    timeout=60.0
                )
                
                if response.status_code != 200:
                    raise HTTPException(status_code=response.status_code, detail=response.text)
                
                result = response.json()
                chatgpt_response = result["choices"][0]["message"]["content"]
                tokens_used = result["usage"]["total_tokens"]
                
                # Generate context ID if not provided
                context_id = request.context_id or f"chatgpt_{int(time.time())}"
                
                # Store updated context
                new_context = {
                    "messages": messages + [{"role": "assistant", "content": chatgpt_response}],
                    "timestamp": time.time(),
                    "model": OPENAI_MODEL,
                    "tokens_used": tokens_used
                }
                
                if context_data:
                    new_context["previous_context"] = context_data
                
                await self.store_context(context_id, new_context)
                
                return ChatGPTResponse(
                    response=chatgpt_response,
                    context_id=context_id,
                    tokens_used=tokens_used
                )
                
        except Exception as e:
            logger.error(f"ChatGPT API error: {e}")
            raise HTTPException(status_code=500, detail=str(e))

# Global server instance
chatgpt_server = ChatGPTServer()

@app.get("/")
async def root():
    return {"name": "ChatGPT MCP Server", "version": "1.0.0", "model": OPENAI_MODEL}

@app.post("/chat", response_model=ChatGPTResponse)
async def chat_with_gpt(request: ChatGPTRequest):
    """Chat with ChatGPT using centralized memory"""
    return await chatgpt_server.chat_completion(request)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "memory_server": MEMORY_SERVER_URL}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
