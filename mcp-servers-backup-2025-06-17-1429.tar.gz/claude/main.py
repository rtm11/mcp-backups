#!/usr/bin/env python3
"""
Claude MCP Server
Integrates Anthropic's Claude with the centralized memory database
"""

import asyncio
import json
import os
import logging
from typing import Any, Dict, List, Optional

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
CLAUDE_API_KEY = os.getenv("CLAUDE_API_KEY", "")
MEMORY_SERVER_URL = os.getenv("MEMORY_SERVER_URL", "http://memory-server:8080")
CLAUDE_MODEL = os.getenv("CLAUDE_MODEL", "claude-3-5-sonnet-20241022")

app = FastAPI(title="Claude MCP Server", version="1.0.0")

class ClaudeRequest(BaseModel):
    messages: List[Dict[str, str]]
    context_id: Optional[str] = None
    system: Optional[str] = None
    max_tokens: Optional[int] = 4096

class ClaudeResponse(BaseModel):
    response: str
    context_id: str
    tokens_used: int

class ClaudeServer:
    def __init__(self):
        self.headers = {
            "Authorization": f"Bearer {CLAUDE_API_KEY}",
            "Content-Type": "application/json",
            "anthropic-version": "2023-06-01",
            "x-api-key": CLAUDE_API_KEY
        }
        self.anthropic_url = "https://api.anthropic.com/v1/messages"

    async def store_context(self, context_id: str, data: Dict[str, Any]) -> None:
        """Store conversation context in memory server"""
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{MEMORY_SERVER_URL}/memory/store",
                    json={
                        "key": f"claude_context_{context_id}",
                        "value": data,
                        "ttl": 3600  # 1 hour
                    }
                )
        except Exception as e:
            logger.warning(f"Failed to store context: {e}")

    async def retrieve_context(self, context_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve conversation context from memory server - check all AI services"""
        try:
            # Try to retrieve from multiple sources (cross-AI memory)
            sources = ["claude_context_", "chatgpt_context_", "gemini_context_", "grok_context_", "perplexity_context_"]
            
            async with httpx.AsyncClient() as client:
                for source in sources:
                    try:
                        response = await client.get(
                            f"{MEMORY_SERVER_URL}/memory/retrieve/{source}{context_id}"
                        )
                        if response.status_code == 200:
                            return response.json().get("data", {}).get("value")
                    except:
                        continue
        except Exception as e:
            logger.warning(f"Failed to retrieve context: {e}")
        return None

    async def chat_completion(self, request: ClaudeRequest) -> ClaudeResponse:
        """Send request to Claude and manage context"""
        try:
            # Retrieve existing context if provided
            context_data = None
            if request.context_id:
                context_data = await self.retrieve_context(request.context_id)
            
            # Prepare Claude API request
            claude_request = {
                "model": CLAUDE_MODEL,
                "max_tokens": request.max_tokens,
                "messages": request.messages
            }
            
            if request.system:
                claude_request["system"] = request.system
            
            # Add context to system message if available
            if context_data:
                context_prompt = f"\n\nContext from previous conversation:\n{json.dumps(context_data, indent=2)}"
                if "system" in claude_request:
                    claude_request["system"] += context_prompt
                else:
                    claude_request["system"] = f"You have access to context from previous conversation:{context_prompt}"

            # Call Claude API
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.anthropic_url,
                    headers=self.headers,
                    json=claude_request,
                    timeout=60.0
                )
                
                if response.status_code != 200:
                    raise HTTPException(status_code=response.status_code, detail=response.text)
                
                result = response.json()
                claude_response = result["content"][0]["text"]
                tokens_used = result["usage"]["output_tokens"]
                
                # Generate context ID if not provided
                context_id = request.context_id or f"claude_{int(time.time())}"
                
                # Store updated context
                new_context = {
                    "messages": request.messages + [{"role": "assistant", "content": claude_response}],
                    "timestamp": time.time(),
                    "model": CLAUDE_MODEL,
                    "tokens_used": tokens_used
                }
                
                if context_data:
                    new_context["previous_context"] = context_data
                
                await self.store_context(context_id, new_context)
                
                return ClaudeResponse(
                    response=claude_response,
                    context_id=context_id,
                    tokens_used=tokens_used
                )
                
        except Exception as e:
            logger.error(f"Claude API error: {e}")
            raise HTTPException(status_code=500, detail=str(e))

# Global server instance
claude_server = ClaudeServer()

@app.get("/")
async def root():
    return {"name": "Claude MCP Server", "version": "1.0.0", "model": CLAUDE_MODEL}

@app.post("/chat", response_model=ClaudeResponse)
async def chat_with_claude(request: ClaudeRequest):
    """Chat with Claude using centralized memory"""
    return await claude_server.chat_completion(request)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "memory_server": MEMORY_SERVER_URL}

if __name__ == "__main__":
    import uvicorn
    import time
    uvicorn.run(app, host="0.0.0.0", port=3000)
