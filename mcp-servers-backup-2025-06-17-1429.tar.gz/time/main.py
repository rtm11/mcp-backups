#!/usr/bin/env python3
"""
Time MCP Server
Provides time-related utilities and scheduling capabilities
"""

import asyncio
import json
import os
import logging
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone, timedelta
import pytz
from croniter import croniter

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from dateutil import parser as date_parser

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
MEMORY_SERVER_URL = os.getenv("MEMORY_SERVER_URL", "http://memory-server:8080")
DEFAULT_TIMEZONE = os.getenv("DEFAULT_TIMEZONE", "UTC")

app = FastAPI(title="Time MCP Server", version="1.0.0")

class TimeRequest(BaseModel):
    timezone: Optional[str] = None
    format: Optional[str] = None
    context_id: Optional[str] = None

class ScheduleRequest(BaseModel):
    cron_expression: str
    description: Optional[str] = None
    timezone: Optional[str] = None
    context_id: Optional[str] = None

class TimeResponse(BaseModel):
    timestamp: str
    timezone: str
    formatted: str
    unix_timestamp: float
    context_id: str

class TimeServer:
    def __init__(self):
        self.default_tz = pytz.timezone(DEFAULT_TIMEZONE)

    async def store_context(self, context_id: str, data: Dict[str, Any]) -> None:
        """Store time operation context in memory server"""
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{MEMORY_SERVER_URL}/store",
                    json={
                        "context_id": context_id,
                        "data": data,
                        "ttl": 3600  # 1 hour TTL
                    }
                )
        except Exception as e:
            logger.error(f"Failed to store context: {e}")

    async def get_current_time(self, timezone_str: Optional[str] = None, 
                              format_str: Optional[str] = None,
                              context_id: str = None) -> Dict[str, Any]:
        """Get current time in specified timezone"""
        try:
            # Determine timezone
            if timezone_str:
                try:
                    tz = pytz.timezone(timezone_str)
                except pytz.exceptions.UnknownTimeZoneError:
                    raise HTTPException(status_code=400, detail=f"Unknown timezone: {timezone_str}")
            else:
                tz = self.default_tz

            # Get current time
            now = datetime.now(tz)
            
            # Format time
            if format_str:
                formatted = now.strftime(format_str)
            else:
                formatted = now.isoformat()

            result = {
                "timestamp": now.isoformat(),
                "timezone": str(tz),
                "formatted": formatted,
                "unix_timestamp": now.timestamp(),
                "utc_timestamp": now.utctimetuple(),
                "local_date": now.date().isoformat(),
                "local_time": now.time().isoformat(),
                "weekday": now.strftime("%A"),
                "month": now.strftime("%B"),
                "year": now.year
            }

            # Store in memory for context
            operation_data = {
                "operation": "get_current_time",
                "timezone": timezone_str or DEFAULT_TIMEZONE,
                "format": format_str,
                "result": result
            }
            await self.store_context(context_id, operation_data)

            return {
                **result,
                "context_id": context_id
            }

        except Exception as e:
            logger.error(f"Time retrieval error: {e}")
            raise HTTPException(status_code=500, detail=f"Time retrieval failed: {e}")

    async def parse_time(self, time_string: str, timezone_str: Optional[str] = None,
                        context_id: str = None) -> Dict[str, Any]:
        """Parse a time string into datetime object"""
        try:
            # Parse the time string
            parsed_time = date_parser.parse(time_string)
            
            # Apply timezone if specified
            if timezone_str:
                try:
                    tz = pytz.timezone(timezone_str)
                    if parsed_time.tzinfo is None:
                        parsed_time = tz.localize(parsed_time)
                    else:
                        parsed_time = parsed_time.astimezone(tz)
                except pytz.exceptions.UnknownTimeZoneError:
                    raise HTTPException(status_code=400, detail=f"Unknown timezone: {timezone_str}")

            result = {
                "original_string": time_string,
                "parsed_timestamp": parsed_time.isoformat(),
                "timezone": str(parsed_time.tzinfo) if parsed_time.tzinfo else "naive",
                "unix_timestamp": parsed_time.timestamp() if parsed_time.tzinfo else None,
                "year": parsed_time.year,
                "month": parsed_time.month,
                "day": parsed_time.day,
                "hour": parsed_time.hour,
                "minute": parsed_time.minute,
                "second": parsed_time.second,
                "weekday": parsed_time.strftime("%A"),
                "is_dst": parsed_time.dst() is not None and parsed_time.dst() != timedelta(0)
            }

            # Store in memory for context
            operation_data = {
                "operation": "parse_time",
                "input": time_string,
                "timezone": timezone_str,
                "result": result
            }
            await self.store_context(context_id, operation_data)

            return {
                **result,
                "context_id": context_id
            }

        except Exception as e:
            logger.error(f"Time parsing error: {e}")
            raise HTTPException(status_code=400, detail=f"Time parsing failed: {e}")

    async def get_timezone_info(self, timezone_str: str, context_id: str = None) -> Dict[str, Any]:
        """Get information about a timezone"""
        try:
            tz = pytz.timezone(timezone_str)
            now = datetime.now(tz)
            
            result = {
                "timezone": timezone_str,
                "current_time": now.isoformat(),
                "utc_offset": str(now.utcoffset()),
                "dst_offset": str(now.dst()) if now.dst() else "No DST",
                "is_dst": now.dst() is not None and now.dst() != timedelta(0),
                "timezone_name": now.tzname(),
                "available_timezones": pytz.all_timezones if timezone_str == "list" else None
            }

            # Store in memory for context
            operation_data = {
                "operation": "get_timezone_info",
                "timezone": timezone_str,
                "result": result
            }
            await self.store_context(context_id, operation_data)

            return {
                **result,
                "context_id": context_id
            }

        except pytz.exceptions.UnknownTimeZoneError:
            raise HTTPException(status_code=400, detail=f"Unknown timezone: {timezone_str}")
        except Exception as e:
            logger.error(f"Timezone info error: {e}")
            raise HTTPException(status_code=500, detail=f"Timezone info failed: {e}")

    async def calculate_duration(self, start_time: str, end_time: str, 
                               context_id: str = None) -> Dict[str, Any]:
        """Calculate duration between two times"""
        try:
            start = date_parser.parse(start_time)
            end = date_parser.parse(end_time)
            
            duration = end - start
            
            result = {
                "start_time": start.isoformat(),
                "end_time": end.isoformat(),
                "duration_seconds": duration.total_seconds(),
                "duration_minutes": duration.total_seconds() / 60,
                "duration_hours": duration.total_seconds() / 3600,
                "duration_days": duration.days,
                "duration_string": str(duration),
                "is_negative": duration.total_seconds() < 0
            }

            # Store in memory for context
            operation_data = {
                "operation": "calculate_duration",
                "start": start_time,
                "end": end_time,
                "result": result
            }
            await self.store_context(context_id, operation_data)

            return {
                **result,
                "context_id": context_id
            }

        except Exception as e:
            logger.error(f"Duration calculation error: {e}")
            raise HTTPException(status_code=400, detail=f"Duration calculation failed: {e}")

    async def get_next_cron_runs(self, cron_expression: str, count: int = 5,
                                timezone_str: Optional[str] = None,
                                context_id: str = None) -> Dict[str, Any]:
        """Get next scheduled runs for a cron expression"""
        try:
            # Determine timezone
            if timezone_str:
                try:
                    tz = pytz.timezone(timezone_str)
                except pytz.exceptions.UnknownTimeZoneError:
                    raise HTTPException(status_code=400, detail=f"Unknown timezone: {timezone_str}")
            else:
                tz = self.default_tz

            # Get current time in specified timezone
            base_time = datetime.now(tz)
            
            # Create croniter object
            cron = croniter(cron_expression, base_time)
            
            # Get next runs
            next_runs = []
            for _ in range(count):
                next_run = cron.get_next(datetime)
                next_runs.append({
                    "timestamp": next_run.isoformat(),
                    "formatted": next_run.strftime("%Y-%m-%d %H:%M:%S %Z"),
                    "unix_timestamp": next_run.timestamp(),
                    "relative_time": str(next_run - base_time)
                })

            result = {
                "cron_expression": cron_expression,
                "timezone": str(tz),
                "base_time": base_time.isoformat(),
                "next_runs": next_runs,
                "is_valid": True
            }

            # Store in memory for context
            operation_data = {
                "operation": "get_next_cron_runs",
                "cron_expression": cron_expression,
                "timezone": timezone_str,
                "count": count,
                "result": result
            }
            await self.store_context(context_id, operation_data)

            return {
                **result,
                "context_id": context_id
            }

        except Exception as e:
            logger.error(f"Cron calculation error: {e}")
            raise HTTPException(status_code=400, detail=f"Invalid cron expression: {e}")

# Initialize server
time_server = TimeServer()

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "memory_server": MEMORY_SERVER_URL,
        "default_timezone": DEFAULT_TIMEZONE,
        "current_time": datetime.now().isoformat()
    }

@app.get("/time/current")
async def get_current_time(timezone: Optional[str] = None, 
                          format: Optional[str] = None,
                          context_id: Optional[str] = None):
    """Get current time"""
    context_id = context_id or f"time_current_{datetime.now().timestamp()}"
    return await time_server.get_current_time(timezone, format, context_id)

@app.post("/time/parse")
async def parse_time(request: dict):
    """Parse a time string"""
    time_string = request.get("time_string")
    timezone = request.get("timezone")
    context_id = request.get("context_id") or f"time_parse_{datetime.now().timestamp()}"
    
    if not time_string:
        raise HTTPException(status_code=400, detail="time_string is required")
    
    return await time_server.parse_time(time_string, timezone, context_id)

@app.get("/time/timezone/{timezone_name}")
async def get_timezone_info(timezone_name: str, context_id: Optional[str] = None):
    """Get timezone information"""
    context_id = context_id or f"timezone_info_{datetime.now().timestamp()}"
    return await time_server.get_timezone_info(timezone_name, context_id)

@app.post("/time/duration")
async def calculate_duration(request: dict):
    """Calculate duration between two times"""
    start_time = request.get("start_time")
    end_time = request.get("end_time")
    context_id = request.get("context_id") or f"duration_{datetime.now().timestamp()}"
    
    if not start_time or not end_time:
        raise HTTPException(status_code=400, detail="start_time and end_time are required")
    
    return await time_server.calculate_duration(start_time, end_time, context_id)

@app.post("/time/cron")
async def get_next_cron_runs(request: ScheduleRequest):
    """Get next cron job runs"""
    context_id = request.context_id or f"cron_{datetime.now().timestamp()}"
    count = request.__dict__.get("count", 5)
    return await time_server.get_next_cron_runs(
        request.cron_expression, count, request.timezone, context_id
    )

@app.get("/time/timezones")
async def list_timezones():
    """List available timezones"""
    return {
        "timezones": sorted(list(pytz.all_timezones)),
        "common_timezones": sorted(list(pytz.common_timezones)),
        "count": len(pytz.all_timezones)
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
