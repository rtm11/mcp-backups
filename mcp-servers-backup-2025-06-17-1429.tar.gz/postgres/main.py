#!/usr/bin/env python3
"""
PostgreSQL MCP Server - Database operations and queries
"""

import os
import json
import logging
import asyncio
from typing import List, Dict, Any, Optional
from datetime import datetime

import asyncpg
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="PostgreSQL MCP Server", version="1.0.0")

# Database configuration
DB_CONFIG = {
    'host': os.getenv('DB_HOST', 'localhost'),
    'port': int(os.getenv('DB_PORT', '5432')),
    'user': os.getenv('DB_USER', 'postgres'),
    'password': os.getenv('DB_PASSWORD', 'password'),
    'database': os.getenv('DB_NAME', 'postgres')
}

# Connection pool
pool = None

class QueryRequest(BaseModel):
    query: str
    params: List[Any] = []
    fetch_mode: str = Field(default="all", description="all, one, or none")

class QueryResult(BaseModel):
    columns: List[str]
    rows: List[List[Any]]
    row_count: int
    execution_time: float

class TableInfo(BaseModel):
    table_name: str
    schema_name: str
    table_type: str
    columns: List[Dict[str, Any]]

async def init_db_pool():
    """Initialize database connection pool"""
    global pool
    try:
        pool = await asyncpg.create_pool(
            host=DB_CONFIG['host'],
            port=DB_CONFIG['port'],
            user=DB_CONFIG['user'],
            password=DB_CONFIG['password'],
            database=DB_CONFIG['database'],
            min_size=2,
            max_size=10,
            command_timeout=60
        )
        logger.info("Database connection pool initialized")
    except Exception as e:
        logger.error(f"Failed to initialize database pool: {e}")
        pool = None

async def close_db_pool():
    """Close database connection pool"""
    global pool
    if pool:
        await pool.close()
        pool = None

@app.on_event("startup")
async def startup_event():
    await init_db_pool()

@app.on_event("shutdown")
async def shutdown_event():
    await close_db_pool()

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    db_status = "disconnected"
    db_info = {}
    
    if pool:
        try:
            async with pool.acquire() as conn:
                result = await conn.fetchrow("SELECT version(), current_database(), current_user")
                db_status = "connected"
                db_info = {
                    "version": result[0],
                    "database": result[1],
                    "user": result[2]
                }
        except Exception as e:
            logger.error(f"Database health check failed: {e}")
            db_status = "error"
    
    return {
        "status": "healthy" if db_status == "connected" else "unhealthy",
        "service": "PostgreSQL MCP Server",
        "timestamp": datetime.now().isoformat(),
        "database_status": db_status,
        "database_info": db_info,
        "config": {
            "host": DB_CONFIG['host'],
            "port": DB_CONFIG['port'],
            "database": DB_CONFIG['database'],
            "user": DB_CONFIG['user']
        }
    }

@app.post("/query", response_model=QueryResult)
async def execute_query(request: QueryRequest):
    """Execute a SQL query"""
    if not pool:
        raise HTTPException(status_code=503, detail="Database connection not available")
    
    start_time = datetime.now()
    
    try:
        async with pool.acquire() as conn:
            # Determine query type and execution method
            query_lower = request.query.lower().strip()
            
            if query_lower.startswith(('select', 'with')):
                # Read queries
                if request.fetch_mode == "one":
                    result = await conn.fetchrow(request.query, *request.params)
                    rows = [list(result.values())] if result else []
                    columns = list(result.keys()) if result else []
                else:
                    result = await conn.fetch(request.query, *request.params)
                    rows = [list(row.values()) for row in result]
                    columns = list(result[0].keys()) if result else []
                
                row_count = len(rows)
            
            elif query_lower.startswith(('insert', 'update', 'delete')):
                # Write queries
                result = await conn.execute(request.query, *request.params)
                row_count = int(result.split()[-1]) if result else 0
                rows = []
                columns = []
            
            else:
                # DDL or other queries
                await conn.execute(request.query, *request.params)
                rows = []
                columns = []
                row_count = 0
            
            execution_time = (datetime.now() - start_time).total_seconds()
            
            return QueryResult(
                columns=columns,
                rows=rows,
                row_count=row_count,
                execution_time=execution_time
            )
    
    except Exception as e:
        logger.error(f"Query execution error: {e}")
        raise HTTPException(status_code=400, detail=f"Query execution failed: {str(e)}")

@app.get("/tables", response_model=List[TableInfo])
async def list_tables(schema: str = "public"):
    """List tables in a schema"""
    if not pool:
        raise HTTPException(status_code=503, detail="Database connection not available")
    
    try:
        async with pool.acquire() as conn:
            # Get tables
            tables_query = """
                SELECT table_name, table_schema, table_type
                FROM information_schema.tables
                WHERE table_schema = $1
                ORDER BY table_name
            """
            tables = await conn.fetch(tables_query, schema)
            
            result = []
            for table in tables:
                # Get columns for each table
                columns_query = """
                    SELECT column_name, data_type, is_nullable, column_default,
                           character_maximum_length, numeric_precision, numeric_scale
                    FROM information_schema.columns
                    WHERE table_schema = $1 AND table_name = $2
                    ORDER BY ordinal_position
                """
                columns = await conn.fetch(columns_query, schema, table['table_name'])
                
                column_info = []
                for col in columns:
                    column_info.append({
                        "name": col['column_name'],
                        "type": col['data_type'],
                        "nullable": col['is_nullable'] == 'YES',
                        "default": col['column_default'],
                        "max_length": col['character_maximum_length'],
                        "precision": col['numeric_precision'],
                        "scale": col['numeric_scale']
                    })
                
                result.append(TableInfo(
                    table_name=table['table_name'],
                    schema_name=table['table_schema'],
                    table_type=table['table_type'],
                    columns=column_info
                ))
            
            return result
    
    except Exception as e:
        logger.error(f"Error listing tables: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/schemas")
async def list_schemas():
    """List database schemas"""
    if not pool:
        raise HTTPException(status_code=503, detail="Database connection not available")
    
    try:
        async with pool.acquire() as conn:
            query = """
                SELECT schema_name
                FROM information_schema.schemata
                WHERE schema_name NOT IN ('information_schema', 'pg_catalog', 'pg_toast')
                ORDER BY schema_name
            """
            result = await conn.fetch(query)
            return {"schemas": [row['schema_name'] for row in result]}
    
    except Exception as e:
        logger.error(f"Error listing schemas: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/table/{schema}/{table}/data")
async def get_table_data(schema: str, table: str, limit: int = 100, offset: int = 0):
    """Get data from a table"""
    if not pool:
        raise HTTPException(status_code=503, detail="Database connection not available")
    
    try:
        async with pool.acquire() as conn:
            # Get total count
            count_query = f'SELECT COUNT(*) FROM "{schema}"."{table}"'
            total_count = await conn.fetchval(count_query)
            
            # Get data
            data_query = f'SELECT * FROM "{schema}"."{table}" LIMIT $1 OFFSET $2'
            rows = await conn.fetch(data_query, limit, offset)
            
            columns = list(rows[0].keys()) if rows else []
            data = [list(row.values()) for row in rows]
            
            return {
                "columns": columns,
                "data": data,
                "total_count": total_count,
                "limit": limit,
                "offset": offset
            }
    
    except Exception as e:
        logger.error(f"Error getting table data: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/databases")
async def list_databases():
    """List all databases"""
    if not pool:
        raise HTTPException(status_code=503, detail="Database connection not available")
    
    try:
        async with pool.acquire() as conn:
            query = """
                SELECT datname, pg_size_pretty(pg_database_size(datname)) as size
                FROM pg_database
                WHERE datistemplate = false
                ORDER BY datname
            """
            result = await conn.fetch(query)
            return {
                "databases": [
                    {"name": row['datname'], "size": row['size']}
                    for row in result
                ]
            }
    
    except Exception as e:
        logger.error(f"Error listing databases: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/stats")
async def get_database_stats():
    """Get database statistics"""
    if not pool:
        raise HTTPException(status_code=503, detail="Database connection not available")
    
    try:
        async with pool.acquire() as conn:
            stats = {}
            
            # Database size
            size_query = "SELECT pg_size_pretty(pg_database_size(current_database())) as size"
            stats['database_size'] = await conn.fetchval(size_query)
            
            # Table count
            table_count_query = """
                SELECT COUNT(*) FROM information_schema.tables
                WHERE table_schema NOT IN ('information_schema', 'pg_catalog', 'pg_toast')
            """
            stats['table_count'] = await conn.fetchval(table_count_query)
            
            # Connection count
            conn_query = "SELECT count(*) FROM pg_stat_activity"
            stats['active_connections'] = await conn.fetchval(conn_query)
            
            # Version info
            version_query = "SELECT version()"
            stats['version'] = await conn.fetchval(version_query)
            
            return stats
    
    except Exception as e:
        logger.error(f"Error getting database stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# MCP Protocol implementation
@app.post("/mcp/tools/call")
async def mcp_tool_call(request: Dict[str, Any]):
    """MCP tool call handler"""
    try:
        tool_name = request.get("name")
        arguments = request.get("arguments", {})
        
        if tool_name == "execute_query":
            query_req = QueryRequest(**arguments)
            result = await execute_query(query_req)
            return {"result": result.dict()}
        
        elif tool_name == "list_tables":
            schema = arguments.get("schema", "public")
            tables = await list_tables(schema)
            return {"result": {"tables": [t.dict() for t in tables]}}
        
        elif tool_name == "get_table_data":
            schema = arguments.get("schema")
            table = arguments.get("table")
            limit = arguments.get("limit", 100)
            offset = arguments.get("offset", 0)
            data = await get_table_data(schema, table, limit, offset)
            return {"result": data}
        
        elif tool_name == "list_schemas":
            schemas = await list_schemas()
            return {"result": schemas}
        
        elif tool_name == "get_database_stats":
            stats = await get_database_stats()
            return {"result": stats}
        
        else:
            raise HTTPException(status_code=400, detail=f"Unknown tool: {tool_name}")
    
    except Exception as e:
        logger.error(f"MCP tool call error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/mcp/tools")
async def mcp_tools():
    """Get available MCP tools"""
    tools = [
        {
            "name": "execute_query",
            "description": "Execute a SQL query",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "SQL query to execute"},
                    "params": {"type": "array", "description": "Query parameters"},
                    "fetch_mode": {"type": "string", "description": "Fetch mode: all, one, or none"}
                },
                "required": ["query"]
            }
        },
        {
            "name": "list_tables",
            "description": "List tables in a schema",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "schema": {"type": "string", "description": "Schema name (default: public)"}
                }
            }
        },
        {
            "name": "get_table_data",
            "description": "Get data from a table",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "schema": {"type": "string", "description": "Schema name"},
                    "table": {"type": "string", "description": "Table name"},
                    "limit": {"type": "integer", "description": "Row limit"},
                    "offset": {"type": "integer", "description": "Row offset"}
                },
                "required": ["schema", "table"]
            }
        },
        {
            "name": "list_schemas",
            "description": "List database schemas",
            "inputSchema": {
                "type": "object",
                "properties": {}
            }
        },
        {
            "name": "get_database_stats",
            "description": "Get database statistics",
            "inputSchema": {
                "type": "object",
                "properties": {}
            }
        }
    ]
    return {"tools": tools}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000, log_level="info")