import uvicorn
from fastapi import FastAPI
from pydantic import BaseModel
import os
import json

app = FastAPI()

class RequestModel(BaseModel):
    context: dict
    params: dict

class ResponseModel(BaseModel):
    data: dict

@app.post("/", response_model=ResponseModel)
async def process_request(request: RequestModel):
    # Basic example: echo back the params
    return ResponseModel(data=request.params)

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port)
