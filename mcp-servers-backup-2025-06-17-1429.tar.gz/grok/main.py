#!/usr/bin/env python3
"""
Grok MCP Server
Integrates X.AI's Grok with the centralized memory database
"""

import asyncio
import json
import os
import logging
import time
from typing import Any, Dict, List, Optional

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
GROK_API_KEY = os.getenv("GROK_API_KEY", "")
MEMORY_SERVER_URL = os.getenv("MEMORY_SERVER_URL", "http://memory-server:8080")
GROK_MODEL = os.getenv("GROK_MODEL", "grok-2-latest")

app = FastAPI(title="Grok MCP Server", version="1.0.0")

class GrokRequest(BaseModel):
    messages: List[Dict[str, str]]
    context_id: Optional[str] = None
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = 4096

class GrokResponse(BaseModel):
    response: str
    context_id: str
    tokens_used: Optional[int] = None

class GrokServer:
    def __init__(self):
        self.headers = {
            "Authorization": f"Bearer {GROK_API_KEY}",
            "Content-Type": "application/json"
        }
        self.grok_url = "https://api.x.ai/v1/chat/completions"

    async def store_context(self, context_id: str, data: Dict[str, Any]) -> None:
        """Store conversation context in memory server"""
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{MEMORY_SERVER_URL}/memory/store",
                    json={
                        "key": f"grok_context_{context_id}",
                        "value": data,
                        "ttl": 3600  # 1 hour
                    }
                )
        except Exception as e:
            logger.warning(f"Failed to store context: {e}")

    async def retrieve_context(self, context_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve conversation context from memory server"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{MEMORY_SERVER_URL}/memory/get/grok_context_{context_id}"
                )
                if response.status_code == 200:
                    return response.json().get("data")
        except Exception as e:
            logger.warning(f"Failed to retrieve context: {e}")
        return None

    async def chat_completion(self, request: GrokRequest) -> GrokResponse:
        """Send request to Grok and manage context"""
        try:
            # Retrieve existing context if provided
            context_data = None
            if request.context_id:
                context_data = await self.retrieve_context(request.context_id)
            
            # Prepare messages with context
            messages = request.messages.copy()
            
            # Add context to conversation if available
            if context_data and "messages" in context_data:
                # Prepend previous messages for continuity
                previous_messages = context_data["messages"][-10:]  # Last 10 messages
                messages = previous_messages + messages

            # Prepare Grok API request
            grok_request = {
                "model": GROK_MODEL,
                "messages": messages,
                "temperature": request.temperature,
                "max_tokens": request.max_tokens,
                "stream": False
            }

            # Call Grok API
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    self.grok_url,
                    headers=self.headers,
                    json=grok_request,
                    timeout=60.0
                )
                
                if response.status_code != 200:
                    raise HTTPException(status_code=response.status_code, detail=response.text)
                
                result = response.json()
                grok_response = result["choices"][0]["message"]["content"]
                tokens_used = result.get("usage", {}).get("total_tokens")
                
                # Generate context ID if not provided
                context_id = request.context_id or f"grok_{int(time.time())}"
                
                # Store updated context
                new_context = {
                    "messages": messages + [{"role": "assistant", "content": grok_response}],
                    "timestamp": time.time(),
                    "model": GROK_MODEL,
                    "tokens_used": tokens_used
                }
                
                if context_data:
                    new_context["previous_context"] = context_data
                
                await self.store_context(context_id, new_context)
                
                return GrokResponse(
                    response=grok_response,
                    context_id=context_id,
                    tokens_used=tokens_used
                )
                
        except Exception as e:
            logger.error(f"Grok API error: {e}")
            raise HTTPException(status_code=500, detail=str(e))

# Global server instance
grok_server = GrokServer()

@app.get("/")
async def root():
    return {"name": "Grok MCP Server", "version": "1.0.0", "model": GROK_MODEL}

@app.post("/chat", response_model=GrokResponse)
async def chat_with_grok(request: GrokRequest):
    """Chat with Grok using centralized memory"""
    return await grok_server.chat_completion(request)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "memory_server": MEMORY_SERVER_URL}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
