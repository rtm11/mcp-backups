#!/usr/bin/env python3
"""
Gemini MCP Server
Integrates Google's Gemini with the centralized memory database
"""

import asyncio
import json
import os
import logging
import time
from typing import Any, Dict, List, Optional

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
MEMORY_SERVER_URL = os.getenv("MEMORY_SERVER_URL", "http://memory-server:8080")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")

app = FastAPI(title="Gemini MCP Server", version="1.0.0")

class GeminiRequest(BaseModel):
    messages: Optional[List[Dict[str, str]]] = None
    message: Optional[str] = None
    context_id: Optional[str] = None
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = 4096

    def model_post_init(self, __context):
        # Convert single message to messages format if needed
        if self.message and not self.messages:
            self.messages = [{"role": "user", "content": self.message}]
        elif not self.messages and not self.message:
            raise ValueError("Either 'messages' or 'message' must be provided")

class GeminiResponse(BaseModel):
    response: str
    context_id: str
    tokens_used: Optional[int] = None

class GeminiServer:
    def __init__(self):
        self.headers = {
            "Content-Type": "application/json"
        }
        self.gemini_url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"

    async def store_context(self, context_id: str, data: Dict[str, Any]) -> None:
        """Store conversation context in memory server"""
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{MEMORY_SERVER_URL}/memory/store",
                    json={
                        "key": f"gemini_context_{context_id}",
                        "value": data,
                        "ttl": 3600  # 1 hour
                    }
                )
        except Exception as e:
            logger.warning(f"Failed to store context: {e}")

    async def retrieve_context(self, context_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve conversation context from memory server"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{MEMORY_SERVER_URL}/memory/get/gemini_context_{context_id}"
                )
                if response.status_code == 200:
                    return response.json().get("data")
        except Exception as e:
            logger.warning(f"Failed to retrieve context: {e}")
        return None

    def convert_messages_to_gemini_format(self, messages: List[Dict[str, str]]) -> List[Dict[str, Any]]:
        """Convert standard messages to Gemini format"""
        gemini_contents = []
        
        for msg in messages:
            role = "user" if msg["role"] == "user" else "model"
            gemini_contents.append({
                "role": role,
                "parts": [{"text": msg["content"]}]
            })
        
        return gemini_contents

    async def chat_completion(self, request: GeminiRequest) -> GeminiResponse:
        """Send request to Gemini and manage context"""
        try:
            # Retrieve existing context if provided
            context_data = None
            if request.context_id:
                context_data = await self.retrieve_context(request.context_id)
            
            # Prepare messages with context
            messages = request.messages.copy()
            
            # Add context to conversation if available
            if context_data and "messages" in context_data:
                # Prepend previous messages for continuity
                previous_messages = context_data["messages"][-10:]  # Last 10 messages
                messages = previous_messages + messages

            # Convert to Gemini format
            gemini_contents = self.convert_messages_to_gemini_format(messages)

            # Prepare Gemini API request
            gemini_request = {
                "contents": gemini_contents,
                "generationConfig": {
                    "temperature": request.temperature,
                    "maxOutputTokens": request.max_tokens,
                }
            }

            # Call Gemini API
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.gemini_url}?key={GEMINI_API_KEY}",
                    headers=self.headers,
                    json=gemini_request,
                    timeout=60.0
                )
                
                if response.status_code != 200:
                    raise HTTPException(status_code=response.status_code, detail=response.text)
                
                result = response.json()
                
                if "candidates" not in result or not result["candidates"]:
                    raise HTTPException(status_code=500, detail="No response from Gemini")
                
                gemini_response = result["candidates"][0]["content"]["parts"][0]["text"]
                tokens_used = result.get("usageMetadata", {}).get("totalTokenCount")
                
                # Generate context ID if not provided
                context_id = request.context_id or f"gemini_{int(time.time())}"
                
                # Store updated context
                new_context = {
                    "messages": messages + [{"role": "assistant", "content": gemini_response}],
                    "timestamp": time.time(),
                    "model": GEMINI_MODEL,
                    "tokens_used": tokens_used
                }
                
                if context_data:
                    new_context["previous_context"] = context_data
                
                await self.store_context(context_id, new_context)
                
                return GeminiResponse(
                    response=gemini_response,
                    context_id=context_id,
                    tokens_used=tokens_used
                )
                
        except Exception as e:
            logger.error(f"Gemini API error: {e}")
            raise HTTPException(status_code=500, detail=str(e))

# Global server instance
gemini_server = GeminiServer()

@app.get("/")
async def root():
    return {"name": "Gemini MCP Server", "version": "1.0.0", "model": GEMINI_MODEL}

@app.post("/chat", response_model=GeminiResponse)
async def chat_with_gemini(request: GeminiRequest):
    """Chat with Gemini using centralized memory"""
    return await gemini_server.chat_completion(request)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "memory_server": MEMORY_SERVER_URL}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
