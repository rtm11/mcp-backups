#!/usr/bin/env python3
"""
Filesystem MCP Server - Secure file operations with sandboxing
"""

import os
import json
import logging
import asyncio
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime

import aiofiles
import magic
from fastapi import FastAPI, HTTPException, UploadFile, File, Query
from fastapi.responses import JSONResponse, FileResponse
from pydantic import BaseModel, Field
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Filesystem MCP Server", version="1.0.0")

# Configuration
ALLOWED_PATHS = os.getenv('ALLOWED_PATHS', '/workspace').split(':')
MAX_FILE_SIZE = int(os.getenv('MAX_FILE_SIZE', '10485760'))  # 10MB default

# Ensure allowed paths exist
for path in ALLOWED_PATHS:
    Path(path).mkdir(parents=True, exist_ok=True)

class FileInfo(BaseModel):
    name: str
    path: str
    size: int
    is_directory: bool
    modified_time: datetime
    mime_type: Optional[str] = None
    permissions: str

class FileContent(BaseModel):
    content: str
    encoding: str = "utf-8"
    mime_type: str

class WriteFileRequest(BaseModel):
    path: str
    content: str
    encoding: str = "utf-8"
    create_dirs: bool = False

class MoveFileRequest(BaseModel):
    source: str
    destination: str

def is_path_allowed(path: str) -> bool:
    """Check if path is within allowed directories"""
    try:
        abs_path = Path(path).resolve()
        return any(abs_path.is_relative_to(Path(allowed).resolve()) for allowed in ALLOWED_PATHS)
    except:
        return False

def get_file_info(path: Path) -> FileInfo:
    """Get detailed file information"""
    stat = path.stat()
    mime_type = None
    
    if path.is_file():
        try:
            mime_type = magic.from_file(str(path), mime=True)
        except:
            mime_type = "application/octet-stream"
    
    return FileInfo(
        name=path.name,
        path=str(path),
        size=stat.st_size,
        is_directory=path.is_dir(),
        modified_time=datetime.fromtimestamp(stat.st_mtime),
        mime_type=mime_type,
        permissions=oct(stat.st_mode)[-3:]
    )

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "Filesystem MCP Server",
        "timestamp": datetime.now().isoformat(),
        "allowed_paths": ALLOWED_PATHS,
        "max_file_size": MAX_FILE_SIZE
    }

@app.get("/files", response_model=List[FileInfo])
async def list_files(path: str = Query("/workspace", description="Directory path to list")):
    """List files and directories"""
    if not is_path_allowed(path):
        raise HTTPException(status_code=403, detail="Path not allowed")
    
    try:
        target_path = Path(path)
        if not target_path.exists():
            raise HTTPException(status_code=404, detail="Path not found")
        
        if not target_path.is_dir():
            return [get_file_info(target_path)]
        
        files = []
        for item in target_path.iterdir():
            try:
                files.append(get_file_info(item))
            except Exception as e:
                logger.warning(f"Error reading file info for {item}: {e}")
        
        return sorted(files, key=lambda x: (not x.is_directory, x.name.lower()))
    
    except Exception as e:
        logger.error(f"Error listing files: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/files/content", response_model=FileContent)
async def read_file(path: str = Query(..., description="File path to read")):
    """Read file content"""
    if not is_path_allowed(path):
        raise HTTPException(status_code=403, detail="Path not allowed")
    
    try:
        file_path = Path(path)
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found")
        
        if file_path.is_dir():
            raise HTTPException(status_code=400, detail="Cannot read directory as file")
        
        if file_path.stat().st_size > MAX_FILE_SIZE:
            raise HTTPException(status_code=413, detail="File too large")
        
        # Detect encoding
        try:
            async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
                content = await f.read()
                encoding = 'utf-8'
        except UnicodeDecodeError:
            async with aiofiles.open(file_path, 'rb') as f:
                raw_content = await f.read()
                content = raw_content.hex()
                encoding = 'hex'
        
        mime_type = magic.from_file(str(file_path), mime=True)
        
        return FileContent(
            content=content,
            encoding=encoding,
            mime_type=mime_type
        )
    
    except Exception as e:
        logger.error(f"Error reading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/files/write")
async def write_file(request: WriteFileRequest):
    """Write content to file"""
    if not is_path_allowed(request.path):
        raise HTTPException(status_code=403, detail="Path not allowed")
    
    try:
        file_path = Path(request.path)
        
        if request.create_dirs:
            file_path.parent.mkdir(parents=True, exist_ok=True)
        
        if not file_path.parent.exists():
            raise HTTPException(status_code=400, detail="Parent directory does not exist")
        
        # Size check
        content_size = len(request.content.encode(request.encoding))
        if content_size > MAX_FILE_SIZE:
            raise HTTPException(status_code=413, detail="Content too large")
        
        async with aiofiles.open(file_path, 'w', encoding=request.encoding) as f:
            await f.write(request.content)
        
        return {"message": "File written successfully", "path": str(file_path)}
    
    except Exception as e:
        logger.error(f"Error writing file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/files/upload")
async def upload_file(file: UploadFile = File(...), path: str = Query(..., description="Upload path")):
    """Upload a file"""
    if not is_path_allowed(path):
        raise HTTPException(status_code=403, detail="Path not allowed")
    
    try:
        upload_path = Path(path) / file.filename
        
        # Size check
        content = await file.read()
        if len(content) > MAX_FILE_SIZE:
            raise HTTPException(status_code=413, detail="File too large")
        
        upload_path.parent.mkdir(parents=True, exist_ok=True)
        
        async with aiofiles.open(upload_path, 'wb') as f:
            await f.write(content)
        
        return {"message": "File uploaded successfully", "path": str(upload_path)}
    
    except Exception as e:
        logger.error(f"Error uploading file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/files")
async def delete_file(path: str = Query(..., description="File path to delete")):
    """Delete a file or directory"""
    if not is_path_allowed(path):
        raise HTTPException(status_code=403, detail="Path not allowed")
    
    try:
        target_path = Path(path)
        if not target_path.exists():
            raise HTTPException(status_code=404, detail="Path not found")
        
        if target_path.is_dir():
            import shutil
            shutil.rmtree(target_path)
        else:
            target_path.unlink()
        
        return {"message": "Deleted successfully", "path": str(target_path)}
    
    except Exception as e:
        logger.error(f"Error deleting file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/files/move")
async def move_file(request: MoveFileRequest):
    """Move or rename a file"""
    if not is_path_allowed(request.source) or not is_path_allowed(request.destination):
        raise HTTPException(status_code=403, detail="Path not allowed")
    
    try:
        source_path = Path(request.source)
        dest_path = Path(request.destination)
        
        if not source_path.exists():
            raise HTTPException(status_code=404, detail="Source path not found")
        
        dest_path.parent.mkdir(parents=True, exist_ok=True)
        source_path.rename(dest_path)
        
        return {"message": "Moved successfully", "from": str(source_path), "to": str(dest_path)}
    
    except Exception as e:
        logger.error(f"Error moving file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/files/copy")
async def copy_file(source: str = Query(...), destination: str = Query(...)):
    """Copy a file"""
    if not is_path_allowed(source) or not is_path_allowed(destination):
        raise HTTPException(status_code=403, detail="Path not allowed")
    
    try:
        source_path = Path(source)
        dest_path = Path(destination)
        
        if not source_path.exists():
            raise HTTPException(status_code=404, detail="Source path not found")
        
        if source_path.is_dir():
            import shutil
            shutil.copytree(source_path, dest_path)
        else:
            dest_path.parent.mkdir(parents=True, exist_ok=True)
            import shutil
            shutil.copy2(source_path, dest_path)
        
        return {"message": "Copied successfully", "from": str(source_path), "to": str(dest_path)}
    
    except Exception as e:
        logger.error(f"Error copying file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/files/search")
async def search_files(query: str = Query(...), path: str = Query("/workspace")):
    """Search for files by name"""
    if not is_path_allowed(path):
        raise HTTPException(status_code=403, detail="Path not allowed")
    
    try:
        search_path = Path(path)
        if not search_path.exists():
            raise HTTPException(status_code=404, detail="Search path not found")
        
        results = []
        for file_path in search_path.rglob(f"*{query}*"):
            if is_path_allowed(str(file_path)):
                try:
                    results.append(get_file_info(file_path))
                except Exception as e:
                    logger.warning(f"Error reading file info for {file_path}: {e}")
        
        return results
    
    except Exception as e:
        logger.error(f"Error searching files: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# MCP Protocol implementation
@app.post("/mcp/tools/call")
async def mcp_tool_call(request: Dict[str, Any]):
    """MCP tool call handler"""
    try:
        tool_name = request.get("name")
        arguments = request.get("arguments", {})
        
        if tool_name == "list_files":
            path = arguments.get("path", "/workspace")
            files = await list_files(path)
            return {"result": {"files": [f.dict() for f in files]}}
        
        elif tool_name == "read_file":
            path = arguments.get("path")
            content = await read_file(path)
            return {"result": content.dict()}
        
        elif tool_name == "write_file":
            write_req = WriteFileRequest(**arguments)
            result = await write_file(write_req)
            return {"result": result}
        
        elif tool_name == "search_files":
            query = arguments.get("query")
            path = arguments.get("path", "/workspace")
            results = await search_files(query, path)
            return {"result": {"files": [f.dict() for f in results]}}
        
        else:
            raise HTTPException(status_code=400, detail=f"Unknown tool: {tool_name}")
    
    except Exception as e:
        logger.error(f"MCP tool call error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/mcp/tools")
async def mcp_tools():
    """Get available MCP tools"""
    tools = [
        {
            "name": "list_files",
            "description": "List files and directories in a path",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Directory path to list"}
                }
            }
        },
        {
            "name": "read_file",
            "description": "Read the content of a file",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path to read"}
                },
                "required": ["path"]
            }
        },
        {
            "name": "write_file",
            "description": "Write content to a file",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "File path to write"},
                    "content": {"type": "string", "description": "Content to write"},
                    "create_dirs": {"type": "boolean", "description": "Create parent directories"}
                },
                "required": ["path", "content"]
            }
        },
        {
            "name": "search_files",
            "description": "Search for files by name pattern",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search pattern"},
                    "path": {"type": "string", "description": "Search root path"}
                },
                "required": ["query"]
            }
        }
    ]
    return {"tools": tools}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000, log_level="info")