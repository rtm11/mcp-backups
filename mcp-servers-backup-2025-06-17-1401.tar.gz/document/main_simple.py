#!/usr/bin/env python3
"""
Simple Document MCP Server
Provides basic document management capabilities integrated with Paperless-ngx, MeiliSearch, and Stirling PDF.
"""

import asyncio
import json
import os
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

import aiofiles
import httpx
import requests
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
PAPERLESS_API_URL = os.getenv("PAPERLESS_API_URL", "http://paperless-ngx:8000/api")
PAPERLESS_API_TOKEN = os.getenv("PAPERLESS_API_TOKEN", "")
MEILISEARCH_URL = os.getenv("MEILISEARCH_URL", "http://meilisearch:7700")
MEILISEARCH_API_KEY = os.getenv("MEILISEARCH_API_KEY", "")
STIRLING_PDF_URL = os.getenv("STIRLING_PDF_URL", "http://stirling-pdf:8080")
N8N_API_TOKEN = os.getenv("N8N_API_TOKEN", "")
N8N_HOST = os.getenv("N8N_HOST", "http://n8n:5678")
MAX_FILE_SIZE = int(os.getenv("MAX_FILE_SIZE", "52428800"))  # 50MB
DOCUMENT_STORAGE_PATH = os.getenv("DOCUMENT_STORAGE_PATH", "/app/documents")

app = FastAPI(title="Document MCP Server", version="1.0.0")

class DocumentServer:
    def __init__(self):
        self.paperless_headers = {
            "Authorization": f"Token {PAPERLESS_API_TOKEN}",
            "Content-Type": "application/json"
        }
        self.meilisearch_headers = {
            "Authorization": f"Bearer {MEILISEARCH_API_KEY}",
            "Content-Type": "application/json"
        }
        self.n8n_headers = {
            "Authorization": f"Bearer {N8N_API_TOKEN}",
            "Content-Type": "application/json"
        }

    async def search_documents(self, query: str, limit: int = 10) -> Dict[str, Any]:
        """Search documents using MeiliSearch"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{MEILISEARCH_URL}/indexes/documents/search",
                    headers=self.meilisearch_headers,
                    json={"q": query, "limit": limit}
                )
                if response.status_code == 200:
                    return response.json()
                else:
                    logger.error(f"MeiliSearch error: {response.status_code}")
                    return {"error": "Search service unavailable"}
        except Exception as e:
            logger.error(f"Search error: {e}")
            return {"error": str(e)}

    async def list_documents(self, page: int = 1, page_size: int = 25) -> Dict[str, Any]:
        """List documents from Paperless-ngx"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{PAPERLESS_API_URL}/documents/",
                    headers=self.paperless_headers,
                    params={"page": page, "page_size": page_size}
                )
                if response.status_code == 200:
                    return response.json()
                else:
                    logger.error(f"Paperless API error: {response.status_code}")
                    return {"error": "Document service unavailable"}
        except Exception as e:
            logger.error(f"List documents error: {e}")
            return {"error": str(e)}

    async def upload_document(self, file_path: str, title: Optional[str] = None) -> Dict[str, Any]:
        """Upload document to Paperless-ngx"""
        try:
            path = Path(file_path)
            if not path.exists():
                return {"error": "File not found"}
            
            files = {"document": (path.name, open(path, "rb"), "application/octet-stream")}
            data = {}
            if title:
                data["title"] = title

            response = requests.post(
                f"{PAPERLESS_API_URL}/documents/post_document/",
                headers={"Authorization": f"Token {PAPERLESS_API_TOKEN}"},
                files=files,
                data=data
            )
            
            if response.status_code in [200, 201]:
                # Trigger N8N workflow if available
                await self.trigger_n8n_workflow("document_uploaded", {
                    "file_path": file_path,
                    "title": title,
                    "upload_response": response.json() if response.status_code == 200 else {}
                })
                return {"success": True, "message": "Document uploaded successfully"}
            else:
                logger.error(f"Upload error: {response.status_code}")
                return {"error": "Upload failed"}
                
        except Exception as e:
            logger.error(f"Upload error: {e}")
            return {"error": str(e)}

    async def trigger_n8n_workflow(self, event_type: str, data: Dict[str, Any]) -> None:
        """Trigger N8N workflow for document processing"""
        if not N8N_API_TOKEN:
            return
        
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{N8N_HOST}/webhook/document-event",
                    headers=self.n8n_headers,
                    json={"event_type": event_type, "data": data}
                )
        except Exception as e:
            logger.warning(f"N8N workflow trigger failed: {e}")

    async def process_pdf(self, file_path: str, operation: str) -> Dict[str, Any]:
        """Process PDF using Stirling PDF tools"""
        try:
            path = Path(file_path)
            if not path.exists():
                return {"error": "File not found"}
            
            files = {"fileInput": (path.name, open(path, "rb"), "application/pdf")}
            
            # Different endpoints for different operations
            endpoints = {
                "compress": "/api/v1/general/compress-pdf",
                "ocr": "/api/v1/convert/pdf/ocr",
                "extract_text": "/api/v1/convert/pdf/extract-text",
                "split": "/api/v1/general/split-pages"
            }
            
            endpoint = endpoints.get(operation)
            if not endpoint:
                return {"error": f"Unknown operation: {operation}"}
            
            response = requests.post(f"{STIRLING_PDF_URL}{endpoint}", files=files)
            
            if response.status_code == 200:
                # Save processed file
                output_path = Path(f"{DOCUMENT_STORAGE_PATH}/export/{path.stem}_{operation}{path.suffix}")
                output_path.parent.mkdir(parents=True, exist_ok=True)
                
                with open(output_path, "wb") as out_f:
                    out_f.write(response.content)
                
                return {"success": True, "output_path": str(output_path)}
            else:
                return {"error": "PDF processing failed"}
                
        except Exception as e:
            logger.error(f"PDF processing error: {e}")
            return {"error": str(e)}

# Global document server instance
document_server = DocumentServer()

# FastAPI endpoints
@app.get("/")
async def root():
    return {"name": "Document MCP Server", "version": "1.0.0"}

@app.get("/capabilities")
async def get_capabilities():
    return {
        "tools": [
            {
                "name": "search_documents",
                "description": "Search documents using full-text search",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "Search query"},
                        "limit": {"type": "integer", "description": "Max results", "default": 10}
                    },
                    "required": ["query"]
                }
            },
            {
                "name": "list_documents",
                "description": "List documents with pagination",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "page": {"type": "integer", "description": "Page number", "default": 1},
                        "page_size": {"type": "integer", "description": "Items per page", "default": 25}
                    }
                }
            },
            {
                "name": "upload_document",
                "description": "Upload a document to the system",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "file_path": {"type": "string", "description": "Path to the file to upload"},
                        "title": {"type": "string", "description": "Optional document title"}
                    },
                    "required": ["file_path"]
                }
            },
            {
                "name": "process_pdf",
                "description": "Process PDF with various operations",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "file_path": {"type": "string", "description": "Path to the PDF file"},
                        "operation": {"type": "string", "enum": ["compress", "ocr", "extract_text", "split"]}
                    },
                    "required": ["file_path", "operation"]
                }
            }
        ]
    }

@app.post("/call-tool")
async def call_tool(request: Dict[str, Any]):
    tool_name = request.get("name")
    arguments = request.get("arguments", {})
    
    try:
        if tool_name == "search_documents":
            query = arguments.get("query", "")
            limit = arguments.get("limit", 10)
            result = await document_server.search_documents(query, limit)
            return {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}
        
        elif tool_name == "list_documents":
            page = arguments.get("page", 1)
            page_size = arguments.get("page_size", 25)
            result = await document_server.list_documents(page, page_size)
            return {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}
        
        elif tool_name == "upload_document":
            file_path = arguments.get("file_path", "")
            title = arguments.get("title")
            result = await document_server.upload_document(file_path, title)
            return {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}
        
        elif tool_name == "process_pdf":
            file_path = arguments.get("file_path", "")
            operation = arguments.get("operation", "")
            result = await document_server.process_pdf(file_path, operation)
            return {"content": [{"type": "text", "text": json.dumps(result, indent=2)}]}
        
        else:
            return {"error": f"Unknown tool: {tool_name}"}
    
    except Exception as e:
        logger.error(f"Tool execution error: {e}")
        return {"error": str(e)}

@app.get("/resources")
async def list_resources():
    """List available document resources"""
    try:
        resources = []
        
        # Input directory
        input_dir = Path(f"{DOCUMENT_STORAGE_PATH}/input")
        if input_dir.exists():
            files = [f.name for f in input_dir.iterdir() if f.is_file()]
            resources.append({
                "uri": "document://storage/input",
                "name": "Document Input Directory",
                "description": f"Contains {len(files)} files ready for processing",
                "mimeType": "application/json"
            })
        
        # Export directory
        export_dir = Path(f"{DOCUMENT_STORAGE_PATH}/export")
        if export_dir.exists():
            files = [f.name for f in export_dir.iterdir() if f.is_file()]
            resources.append({
                "uri": "document://storage/export",
                "name": "Processed Documents",
                "description": f"Contains {len(files)} processed files",
                "mimeType": "application/json"
            })
        
        return {"resources": resources}
    
    except Exception as e:
        logger.error(f"List resources error: {e}")
        return {"resources": []}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
