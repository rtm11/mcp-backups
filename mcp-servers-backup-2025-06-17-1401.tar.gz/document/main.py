#!/usr/bin/env python3
"""
Document MCP Server - AI Services Stack
Provides document management capabilities through MCP protocol
"""

import asyncio
import json
import logging
import os
import requests
import aiofiles
from pathlib import Path
from typing import Any, Dict, List, Optional
from mcp.server import NotificationOptions, Server
from mcp.server.models import InitializationOptions
from mcp import types
import mcp.server.stdio
    JSONRPCNotification,
    JSONRPCRequest,
)

# Configuration
PAPERLESS_API_URL = os.getenv("PAPERLESS_API_URL", "http://paperless-ngx:8000/api")
PAPERLESS_API_TOKEN = os.getenv("PAPERLESS_API_TOKEN", "")
MEILISEARCH_URL = os.getenv("MEILISEARCH_URL", "http://meilisearch:7700")
MEILISEARCH_API_KEY = os.getenv("MEILISEARCH_API_KEY", "")
STIRLING_PDF_URL = os.getenv("STIRLING_PDF_URL", "http://stirling-pdf:8080")
MAX_FILE_SIZE = int(os.getenv("MAX_FILE_SIZE", "52428800"))  # 50MB
DOCUMENT_STORAGE_PATH = os.getenv("DOCUMENT_STORAGE_PATH", "/app/documents")

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create storage directories
Path(f"{DOCUMENT_STORAGE_PATH}/input").mkdir(parents=True, exist_ok=True)
Path(f"{DOCUMENT_STORAGE_PATH}/export").mkdir(parents=True, exist_ok=True)

app = Server("document-mcp")

class DocumentMCPServer:
    def __init__(self):
        self.paperless_headers = {
            "Authorization": f"Token {PAPERLESS_API_TOKEN}",
            "Content-Type": "application/json"
        }
        self.meilisearch_headers = {
            "Authorization": f"Bearer {MEILISEARCH_API_KEY}",
            "Content-Type": "application/json"
        }

    async def search_documents(self, query: str, limit: int = 10) -> Dict[str, Any]:
        """Search documents using MeiliSearch"""
        try:
            search_data = {
                "q": query,
                "limit": limit,
                "attributesToRetrieve": ["*"],
                "attributesToHighlight": ["title", "content"]
            }
            
            response = requests.post(
                f"{MEILISEARCH_URL}/indexes/documents/search",
                headers=self.meilisearch_headers,
                json=search_data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Document search failed: {e}")
            return {"hits": [], "error": str(e)}

    async def get_document_info(self, doc_id: int) -> Dict[str, Any]:
        """Get document information from Paperless"""
        try:
            response = requests.get(
                f"{PAPERLESS_API_URL}/documents/{doc_id}/",
                headers=self.paperless_headers
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Failed to get document info: {e}")
            return {"error": str(e)}

    async def list_documents(self, page: int = 1, page_size: int = 25) -> Dict[str, Any]:
        """List documents from Paperless"""
        try:
            params = {
                "page": page,
                "page_size": page_size,
                "ordering": "-created"
            }
            response = requests.get(
                f"{PAPERLESS_API_URL}/documents/",
                headers=self.paperless_headers,
                params=params
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Failed to list documents: {e}")
            return {"results": [], "error": str(e)}

    async def upload_document(self, file_path: str, title: str = None) -> Dict[str, Any]:
        """Upload document to Paperless"""
        try:
            file_path = Path(file_path)
            if not file_path.exists():
                return {"error": "File not found"}
            
            if file_path.stat().st_size > MAX_FILE_SIZE:
                return {"error": f"File too large. Max size: {MAX_FILE_SIZE} bytes"}

            with open(file_path, 'rb') as f:
                files = {'document': (file_path.name, f, 'application/pdf')}
                data = {}
                if title:
                    data['title'] = title
                
                response = requests.post(
                    f"{PAPERLESS_API_URL}/documents/post_document/",
                    headers={"Authorization": f"Token {PAPERLESS_API_TOKEN}"},
                    files=files,
                    data=data
                )
                response.raise_for_status()
                return response.json()
        except Exception as e:
            logger.error(f"Document upload failed: {e}")
            return {"error": str(e)}

    async def process_pdf(self, operation: str, file_path: str, **kwargs) -> Dict[str, Any]:
        """Process PDF using Stirling PDF"""
        try:
            file_path = Path(file_path)
            if not file_path.exists():
                return {"error": "File not found"}

            with open(file_path, 'rb') as f:
                files = {'fileInput': (file_path.name, f, 'application/pdf')}
                
                # Different operations for Stirling PDF
                endpoints = {
                    "merge": "/api/v1/merge-pdfs",
                    "split": "/api/v1/split-pages",
                    "compress": "/api/v1/compress-pdf",
                    "extract-text": "/api/v1/extract/extract-page-content",
                    "convert-to-images": "/api/v1/convert/pdf/img"
                }
                
                endpoint = endpoints.get(operation)
                if not endpoint:
                    return {"error": f"Unknown operation: {operation}"}
                
                response = requests.post(
                    f"{STIRLING_PDF_URL}{endpoint}",
                    files=files,
                    data=kwargs
                )
                response.raise_for_status()
                
                # Save processed file
                output_path = Path(f"{DOCUMENT_STORAGE_PATH}/export/{file_path.stem}_{operation}{file_path.suffix}")
                with open(output_path, 'wb') as out_f:
                    out_f.write(response.content)
                
                return {
                    "success": True,
                    "output_file": str(output_path),
                    "operation": operation
                }
        except Exception as e:
            logger.error(f"PDF processing failed: {e}")
            return {"error": str(e)}

document_server = DocumentMCPServer()

@app.list_tools()
async def handle_list_tools() -> ListToolsResult:
    """List available document management tools"""
    return ListToolsResult(
        tools=[
            Tool(
                name="search_documents",
                description="Search documents using AI-powered search",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query for documents"
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Maximum number of results (default: 10)",
                            "default": 10
                        }
                    },
                    "required": ["query"]
                }
            ),
            Tool(
                name="get_document",
                description="Get detailed information about a specific document",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "doc_id": {
                            "type": "integer",
                            "description": "Document ID"
                        }
                    },
                    "required": ["doc_id"]
                }
            ),
            Tool(
                name="list_documents",
                description="List all documents with pagination",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "page": {
                            "type": "integer",
                            "description": "Page number (default: 1)",
                            "default": 1
                        },
                        "page_size": {
                            "type": "integer",
                            "description": "Items per page (default: 25)",
                            "default": 25
                        }
                    }
                }
            ),
            Tool(
                name="upload_document",
                description="Upload a document to the document management system",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to the file to upload"
                        },
                        "title": {
                            "type": "string",
                            "description": "Optional title for the document"
                        }
                    },
                    "required": ["file_path"]
                }
            ),
            Tool(
                name="process_pdf",
                description="Process PDF files (merge, split, compress, extract text, convert to images)",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "operation": {
                            "type": "string",
                            "enum": ["merge", "split", "compress", "extract-text", "convert-to-images"],
                            "description": "PDF operation to perform"
                        },
                        "file_path": {
                            "type": "string",
                            "description": "Path to the PDF file"
                        }
                    },
                    "required": ["operation", "file_path"]
                }
            )
        ]
    )

@app.call_tool()
async def handle_call_tool(request: CallToolRequest) -> CallToolResult:
    """Handle tool calls for document operations"""
    try:
        if request.name == "search_documents":
            query = request.arguments.get("query", "")
            limit = request.arguments.get("limit", 10)
            result = await document_server.search_documents(query, limit)
            return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])
        
        elif request.name == "get_document":
            doc_id = request.arguments.get("doc_id")
            result = await document_server.get_document_info(doc_id)
            return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])
        
        elif request.name == "list_documents":
            page = request.arguments.get("page", 1)
            page_size = request.arguments.get("page_size", 25)
            result = await document_server.list_documents(page, page_size)
            return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])
        
        elif request.name == "upload_document":
            file_path = request.arguments.get("file_path", "")
            title = request.arguments.get("title")
            result = await document_server.upload_document(file_path, title)
            return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])
        
        elif request.name == "process_pdf":
            operation = request.arguments.get("operation", "")
            file_path = request.arguments.get("file_path", "")
            result = await document_server.process_pdf(operation, file_path)
            return CallToolResult(content=[TextContent(type="text", text=json.dumps(result, indent=2))])
        
        else:
            return CallToolResult(
                content=[TextContent(type="text", text=f"Unknown tool: {request.name}")],
                isError=True
            )
    
    except Exception as e:
        logger.error(f"Tool call failed: {e}")
        return CallToolResult(
            content=[TextContent(type="text", text=f"Error: {str(e)}")],
            isError=True
        )

@app.list_resources()
async def handle_list_resources() -> ListResourcesResult:
    """List available document resources"""
    return ListResourcesResult(
        resources=[
            Resource(
                uri="document://storage/input",
                name="Document Input Directory",
                description="Directory for incoming documents",
                mimeType="inode/directory"
            ),
            Resource(
                uri="document://storage/export",
                name="Document Export Directory", 
                description="Directory for processed documents",
                mimeType="inode/directory"
            )
        ]
    )

@app.read_resource()
async def handle_read_resource(request: ReadResourceRequest) -> ReadResourceResult:
    """Read document resources"""
    try:
        uri = request.uri
        if uri == "document://storage/input":
            input_dir = Path(f"{DOCUMENT_STORAGE_PATH}/input")
            files = [f.name for f in input_dir.iterdir() if f.is_file()]
            return ReadResourceResult(
                contents=[TextContent(
                    type="text",
                    text=f"Input directory contents:\n" + "\n".join(files)
                )]
            )
        elif uri == "document://storage/export":
            export_dir = Path(f"{DOCUMENT_STORAGE_PATH}/export")
            files = [f.name for f in export_dir.iterdir() if f.is_file()]
            return ReadResourceResult(
                contents=[TextContent(
                    type="text",
                    text=f"Export directory contents:\n" + "\n".join(files)
                )]
            )
        else:
            return ReadResourceResult(
                contents=[TextContent(
                    type="text",
                    text=f"Unknown resource: {uri}"
                )],
                isError=True
            )
    except Exception as e:
        return ReadResourceResult(
            contents=[TextContent(
                type="text",
                text=f"Error reading resource: {str(e)}"
            )],
            isError=True
        )

async def main():
    """Run the Document MCP server"""
    from mcp.server.stdio import stdio_server
    
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="document-mcp",
                server_version="1.0.0",
                capabilities=app.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={}
                )
            )
        )

if __name__ == "__main__":
    asyncio.run(main())
