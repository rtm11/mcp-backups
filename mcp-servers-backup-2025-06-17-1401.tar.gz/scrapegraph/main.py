#!/usr/bin/env python3
"""
ScrapeGraph MCP Server
Integrates ScrapeGraph AI with the centralized memory database
"""

import asyncio
import json
import os
import logging
import time
from typing import Any, Dict, List, Optional

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
SCRAPEGRAPH_API_KEY = os.getenv("SCRAPEGRAPH_API_KEY", "")
MEMORY_SERVER_URL = os.getenv("MEMORY_SERVER_URL", "http://memory-server:8080")

app = FastAPI(title="ScrapeGraph MCP Server", version="1.0.0")

class ScrapeRequest(BaseModel):
    url: str
    prompt: Optional[str] = None
    context_id: Optional[str] = None
    format: Optional[str] = "json"

class ScrapeResponse(BaseModel):
    response: str
    context_id: str
    url: str
    timestamp: float

class ScrapeGraphServer:
    def __init__(self):
        self.headers = {
            "Authorization": f"Bearer {SCRAPEGRAPH_API_KEY}",
            "Content-Type": "application/json"
        }
        self.scrapegraph_url = "https://api.scrapegraphai.com/v1"

    async def store_context(self, context_id: str, data: Dict[str, Any]) -> None:
        """Store conversation context in memory server"""
        try:
            async with httpx.AsyncClient() as client:
                await client.post(
                    f"{MEMORY_SERVER_URL}/memory",
                    json={
                        "context_id": context_id,
                        "data": data,
                        "source": "scrapegraph"
                    },
                    timeout=30.0
                )
        except Exception as e:
            logger.error(f"Failed to store context: {e}")

    async def get_context(self, context_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve conversation context from memory server"""
        try:
            async with httpx.AsyncClient() as client:
                response = await client.get(
                    f"{MEMORY_SERVER_URL}/memory/{context_id}",
                    timeout=30.0
                )
                if response.status_code == 200:
                    return response.json().get("data")
                return None
        except Exception as e:
            logger.error(f"Failed to get context: {e}")
            return None

    async def scrape_website(self, request: ScrapeRequest) -> ScrapeResponse:
        """Scrape website with ScrapeGraph AI"""
        try:
            # Get existing context if provided
            context_data = None
            if request.context_id:
                context_data = await self.get_context(request.context_id)

            # Prepare the scraping request
            payload = {
                "url": request.url,
                "prompt": request.prompt or "Extract all relevant information from this webpage",
                "format": request.format
            }

            # Make request to ScrapeGraph API
            async with httpx.AsyncClient() as client:
                response = await client.post(
                    f"{self.scrapegraph_url}/scrape",
                    headers=self.headers,
                    json=payload,
                    timeout=60.0
                )
                
                if response.status_code != 200:
                    raise HTTPException(
                        status_code=response.status_code,
                        detail=f"ScrapeGraph API error: {response.text}"
                    )
                
                result = response.json()
                
                if "error" in result:
                    raise HTTPException(status_code=500, detail=result["error"])
                
                scraped_content = result.get("result", "No content extracted")
                
                # Generate context ID if not provided
                context_id = request.context_id or f"scrapegraph_{int(time.time())}"
                
                # Store updated context
                new_context = {
                    "url": request.url,
                    "prompt": request.prompt,
                    "result": scraped_content,
                    "timestamp": time.time(),
                    "format": request.format
                }
                
                if context_data:
                    new_context["previous_scrapes"] = context_data.get("previous_scrapes", [])
                    new_context["previous_scrapes"].append({
                        "url": request.url,
                        "timestamp": context_data.get("timestamp"),
                        "result_preview": str(context_data.get("result", ""))[:200]
                    })

                await self.store_context(context_id, new_context)
                
                return ScrapeResponse(
                    response=scraped_content,
                    context_id=context_id,
                    url=request.url,
                    timestamp=time.time()
                )
                
        except httpx.RequestError as e:
            logger.error(f"Network error: {e}")
            raise HTTPException(status_code=503, detail=f"Network error: {str(e)}")
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            raise HTTPException(status_code=500, detail=str(e))

# Global server instance
scrapegraph_server = ScrapeGraphServer()

@app.get("/")
async def root():
    return {"name": "ScrapeGraph MCP Server", "version": "1.0.0", "api": "ScrapeGraph AI"}

@app.post("/scrape", response_model=ScrapeResponse)
async def scrape_website(request: ScrapeRequest):
    """Scrape website using ScrapeGraph AI with centralized memory"""
    return await scrapegraph_server.scrape_website(request)

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "memory_server": MEMORY_SERVER_URL}

@app.get("/memory/{context_id}")
async def get_memory(context_id: str):
    """Get stored memory for a context"""
    context_data = await scrapegraph_server.get_context(context_id)
    if context_data:
        return {"context_id": context_id, "data": context_data}
    else:
        return {"context_id": context_id, "data": None, "message": "No memory found"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000)
