#!/usr/bin/env python3
"""
Redis MCP Server - Redis operations and caching
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional, Union
from datetime import datetime

import redis.asyncio as redis
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Redis MCP Server", version="1.0.0")

# Redis configuration
REDIS_CONFIG = {
    'host': os.getenv('REDIS_HOST', 'localhost'),
    'port': int(os.getenv('REDIS_PORT', '6379')),
    'password': os.getenv('REDIS_PASSWORD', None),
    'db': int(os.getenv('REDIS_DB', '0'))
}

# Redis client
redis_client = None

class SetRequest(BaseModel):
    key: str
    value: Union[str, int, float, bool, dict, list]
    ttl: Optional[int] = None

class GetRequest(BaseModel):
    key: str

class DeleteRequest(BaseModel):
    keys: List[str]

class HashSetRequest(BaseModel):
    key: str
    field: str
    value: Union[str, int, float, bool]

class ListPushRequest(BaseModel):
    key: str
    values: List[Union[str, int, float, bool]]
    direction: str = Field(default="left", description="left or right")

class SetAddRequest(BaseModel):
    key: str
    members: List[Union[str, int, float]]

async def init_redis():
    """Initialize Redis connection"""
    global redis_client
    try:
        redis_client = redis.Redis(
            host=REDIS_CONFIG['host'],
            port=REDIS_CONFIG['port'],
            password=REDIS_CONFIG['password'],
            db=REDIS_CONFIG['db'],
            decode_responses=True
        )
        await redis_client.ping()
        logger.info("Redis connection initialized")
    except Exception as e:
        logger.error(f"Failed to initialize Redis connection: {e}")
        redis_client = None

async def close_redis():
    """Close Redis connection"""
    global redis_client
    if redis_client:
        await redis_client.close()
        redis_client = None

@app.on_event("startup")
async def startup_event():
    await init_redis()

@app.on_event("shutdown")
async def shutdown_event():
    await close_redis()

def serialize_value(value):
    """Serialize value for Redis storage"""
    if isinstance(value, (dict, list)):
        return json.dumps(value)
    return str(value)

def deserialize_value(value, original_type=None):
    """Deserialize value from Redis"""
    if value is None:
        return None
    
    if isinstance(value, str):
        # Try to parse as JSON first
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value
    
    return value

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    redis_status = "disconnected"
    redis_info = {}
    
    if redis_client:
        try:
            await redis_client.ping()
            redis_status = "connected"
            info = await redis_client.info()
            redis_info = {
                "version": info.get("redis_version", "unknown"),
                "mode": info.get("redis_mode", "unknown"),
                "connected_clients": info.get("connected_clients", 0),
                "used_memory": info.get("used_memory_human", "unknown"),
                "total_commands_processed": info.get("total_commands_processed", 0)
            }
        except Exception as e:
            logger.error(f"Redis health check failed: {e}")
            redis_status = "error"
    
    return {
        "status": "healthy" if redis_status == "connected" else "unhealthy",
        "service": "Redis MCP Server",
        "timestamp": datetime.now().isoformat(),
        "redis_status": redis_status,
        "redis_info": redis_info,
        "config": {
            "host": REDIS_CONFIG['host'],
            "port": REDIS_CONFIG['port'],
            "database": REDIS_CONFIG['db']
        }
    }

@app.post("/set")
async def set_value(request: SetRequest):
    """Set a key-value pair"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        serialized_value = serialize_value(request.value)
        if request.ttl:
            await redis_client.setex(request.key, request.ttl, serialized_value)
        else:
            await redis_client.set(request.key, serialized_value)
        
        return {"message": f"Key '{request.key}' set successfully"}
    
    except Exception as e:
        logger.error(f"Error setting value: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/get/{key}")
async def get_value(key: str):
    """Get a value by key"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        value = await redis_client.get(key)
        if value is None:
            raise HTTPException(status_code=404, detail="Key not found")
        
        return {"key": key, "value": deserialize_value(value)}
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting value: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.delete("/delete")
async def delete_keys(request: DeleteRequest):
    """Delete one or more keys"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        deleted_count = await redis_client.delete(*request.keys)
        return {"message": f"Deleted {deleted_count} keys", "deleted_count": deleted_count}
    
    except Exception as e:
        logger.error(f"Error deleting keys: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/keys")
async def list_keys(pattern: str = "*", limit: int = 100):
    """List keys matching a pattern"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        keys = []
        async for key in redis_client.scan_iter(match=pattern, count=limit):
            keys.append(key)
            if len(keys) >= limit:
                break
        
        return {"keys": keys, "count": len(keys), "pattern": pattern}
    
    except Exception as e:
        logger.error(f"Error listing keys: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/exists/{key}")
async def key_exists(key: str):
    """Check if a key exists"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        exists = await redis_client.exists(key)
        return {"key": key, "exists": bool(exists)}
    
    except Exception as e:
        logger.error(f"Error checking key existence: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/ttl/{key}")
async def get_ttl(key: str):
    """Get time to live for a key"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        ttl = await redis_client.ttl(key)
        return {"key": key, "ttl": ttl}
    
    except Exception as e:
        logger.error(f"Error getting TTL: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/expire/{key}")
async def set_expire(key: str, seconds: int):
    """Set expiration time for a key"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        result = await redis_client.expire(key, seconds)
        return {"key": key, "expire_set": bool(result)}
    
    except Exception as e:
        logger.error(f"Error setting expiration: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Hash operations
@app.post("/hash/set")
async def hash_set(request: HashSetRequest):
    """Set a hash field"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        await redis_client.hset(request.key, request.field, serialize_value(request.value))
        return {"message": f"Hash field '{request.field}' set in '{request.key}'"}
    
    except Exception as e:
        logger.error(f"Error setting hash field: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/hash/get/{key}/{field}")
async def hash_get(key: str, field: str):
    """Get a hash field value"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        value = await redis_client.hget(key, field)
        if value is None:
            raise HTTPException(status_code=404, detail="Hash field not found")
        
        return {"key": key, "field": field, "value": deserialize_value(value)}
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting hash field: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/hash/getall/{key}")
async def hash_get_all(key: str):
    """Get all hash fields and values"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        hash_data = await redis_client.hgetall(key)
        if not hash_data:
            raise HTTPException(status_code=404, detail="Hash not found")
        
        result = {field: deserialize_value(value) for field, value in hash_data.items()}
        return {"key": key, "hash": result}
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting hash: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# List operations
@app.post("/list/push")
async def list_push(request: ListPushRequest):
    """Push values to a list"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        serialized_values = [serialize_value(v) for v in request.values]
        
        if request.direction == "left":
            length = await redis_client.lpush(request.key, *serialized_values)
        else:
            length = await redis_client.rpush(request.key, *serialized_values)
        
        return {"message": f"Pushed {len(request.values)} values to list", "new_length": length}
    
    except Exception as e:
        logger.error(f"Error pushing to list: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/list/range/{key}")
async def list_range(key: str, start: int = 0, end: int = -1):
    """Get a range of list elements"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        values = await redis_client.lrange(key, start, end)
        result = [deserialize_value(v) for v in values]
        return {"key": key, "values": result, "count": len(result)}
    
    except Exception as e:
        logger.error(f"Error getting list range: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# Set operations
@app.post("/set/add")
async def set_add(request: SetAddRequest):
    """Add members to a set"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        serialized_members = [serialize_value(m) for m in request.members]
        added_count = await redis_client.sadd(request.key, *serialized_members)
        return {"message": f"Added {added_count} new members to set", "added_count": added_count}
    
    except Exception as e:
        logger.error(f"Error adding to set: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/set/members/{key}")
async def set_members(key: str):
    """Get all members of a set"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        members = await redis_client.smembers(key)
        result = [deserialize_value(m) for m in members]
        return {"key": key, "members": result, "count": len(result)}
    
    except Exception as e:
        logger.error(f"Error getting set members: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/info")
async def get_redis_info():
    """Get Redis server information"""
    if not redis_client:
        raise HTTPException(status_code=503, detail="Redis connection not available")
    
    try:
        info = await redis_client.info()
        return {
            "server": {
                "version": info.get("redis_version"),
                "mode": info.get("redis_mode"),
                "os": info.get("os"),
                "arch_bits": info.get("arch_bits")
            },
            "clients": {
                "connected_clients": info.get("connected_clients"),
                "client_longest_output_list": info.get("client_longest_output_list")
            },
            "memory": {
                "used_memory": info.get("used_memory"),
                "used_memory_human": info.get("used_memory_human"),
                "used_memory_peak": info.get("used_memory_peak"),
                "used_memory_peak_human": info.get("used_memory_peak_human")
            },
            "stats": {
                "total_connections_received": info.get("total_connections_received"),
                "total_commands_processed": info.get("total_commands_processed"),
                "keyspace_hits": info.get("keyspace_hits"),
                "keyspace_misses": info.get("keyspace_misses")
            }
        }
    
    except Exception as e:
        logger.error(f"Error getting Redis info: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# MCP Protocol implementation
@app.post("/mcp/tools/call")
async def mcp_tool_call(request: Dict[str, Any]):
    """MCP tool call handler"""
    try:
        tool_name = request.get("name")
        arguments = request.get("arguments", {})
        
        if tool_name == "set_value":
            set_req = SetRequest(**arguments)
            result = await set_value(set_req)
            return {"result": result}
        
        elif tool_name == "get_value":
            key = arguments.get("key")
            result = await get_value(key)
            return {"result": result}
        
        elif tool_name == "list_keys":
            pattern = arguments.get("pattern", "*")
            limit = arguments.get("limit", 100)
            result = await list_keys(pattern, limit)
            return {"result": result}
        
        elif tool_name == "delete_keys":
            del_req = DeleteRequest(**arguments)
            result = await delete_keys(del_req)
            return {"result": result}
        
        elif tool_name == "get_redis_info":
            result = await get_redis_info()
            return {"result": result}
        
        else:
            raise HTTPException(status_code=400, detail=f"Unknown tool: {tool_name}")
    
    except Exception as e:
        logger.error(f"MCP tool call error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/mcp/tools")
async def mcp_tools():
    """Get available MCP tools"""
    tools = [
        {
            "name": "set_value",
            "description": "Set a key-value pair in Redis",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "key": {"type": "string", "description": "Redis key"},
                    "value": {"description": "Value to store"},
                    "ttl": {"type": "integer", "description": "Time to live in seconds"}
                },
                "required": ["key", "value"]
            }
        },
        {
            "name": "get_value",
            "description": "Get a value by key from Redis",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "key": {"type": "string", "description": "Redis key"}
                },
                "required": ["key"]
            }
        },
        {
            "name": "list_keys",
            "description": "List Redis keys matching a pattern",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "pattern": {"type": "string", "description": "Key pattern (default: *)"},
                    "limit": {"type": "integer", "description": "Maximum number of keys"}
                }
            }
        },
        {
            "name": "delete_keys",
            "description": "Delete one or more Redis keys",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "keys": {"type": "array", "items": {"type": "string"}, "description": "Keys to delete"}
                },
                "required": ["keys"]
            }
        },
        {
            "name": "get_redis_info",
            "description": "Get Redis server information and statistics",
            "inputSchema": {
                "type": "object",
                "properties": {}
            }
        }
    ]
    return {"tools": tools}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000, log_level="info")