print("Hello from main.py - replace with your actual server code!")
