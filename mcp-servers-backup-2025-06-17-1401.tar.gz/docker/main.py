#!/usr/bin/env python3
"""
Docker MCP Server - Docker operations and management
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime

import docker
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Docker MCP Server", version="1.0.0")

# Initialize Docker client
try:
    docker_client = docker.from_env()
    logger.info("Docker client initialized successfully")
except Exception as e:
    logger.error(f"Failed to initialize Docker client: {e}")
    docker_client = None

class ContainerInfo(BaseModel):
    id: str
    name: str
    image: str
    status: str
    state: str
    created: datetime
    ports: Dict[str, Any]
    labels: Dict[str, str]

class ImageInfo(BaseModel):
    id: str
    tags: List[str]
    created: datetime
    size: int
    labels: Dict[str, str]

class VolumeInfo(BaseModel):
    name: str
    driver: str
    mountpoint: str
    created: datetime
    labels: Dict[str, str]

class NetworkInfo(BaseModel):
    id: str
    name: str
    driver: str
    scope: str
    created: datetime
    labels: Dict[str, str]

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    docker_status = "connected" if docker_client else "disconnected"
    
    system_info = {}
    if docker_client:
        try:
            info = docker_client.info()
            system_info = {
                "containers": info.get("Containers", 0),
                "images": info.get("Images", 0),
                "server_version": info.get("ServerVersion", "unknown"),
                "architecture": info.get("Architecture", "unknown"),
                "operating_system": info.get("OperatingSystem", "unknown")
            }
        except Exception as e:
            logger.error(f"Error getting Docker info: {e}")
    
    return {
        "status": "healthy" if docker_client else "unhealthy",
        "service": "Docker MCP Server",
        "timestamp": datetime.now().isoformat(),
        "docker_status": docker_status,
        "system_info": system_info
    }

@app.get("/containers", response_model=List[ContainerInfo])
async def list_containers(all: bool = False):
    """List Docker containers"""
    if not docker_client:
        raise HTTPException(status_code=503, detail="Docker client not available")
    
    try:
        containers = docker_client.containers.list(all=all)
        result = []
        
        for container in containers:
            result.append(ContainerInfo(
                id=container.id[:12],
                name=container.name,
                image=container.image.tags[0] if container.image.tags else container.image.id[:12],
                status=container.status,
                state=container.attrs["State"]["Status"],
                created=datetime.fromisoformat(container.attrs["Created"].replace("Z", "+00:00")),
                ports=container.attrs["NetworkSettings"]["Ports"],
                labels=container.labels
            ))
        
        return result
    
    except Exception as e:
        logger.error(f"Error listing containers: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/containers/{container_id}")
async def get_container(container_id: str):
    """Get detailed container information"""
    if not docker_client:
        raise HTTPException(status_code=503, detail="Docker client not available")
    
    try:
        container = docker_client.containers.get(container_id)
        return {
            "id": container.id,
            "name": container.name,
            "image": container.image.tags[0] if container.image.tags else container.image.id,
            "status": container.status,
            "attrs": container.attrs
        }
    except docker.errors.NotFound:
        raise HTTPException(status_code=404, detail="Container not found")
    except Exception as e:
        logger.error(f"Error getting container: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/containers/{container_id}/start")
async def start_container(container_id: str):
    """Start a container"""
    if not docker_client:
        raise HTTPException(status_code=503, detail="Docker client not available")
    
    try:
        container = docker_client.containers.get(container_id)
        container.start()
        return {"message": f"Container {container_id} started successfully"}
    except docker.errors.NotFound:
        raise HTTPException(status_code=404, detail="Container not found")
    except Exception as e:
        logger.error(f"Error starting container: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/containers/{container_id}/stop")
async def stop_container(container_id: str, timeout: int = 10):
    """Stop a container"""
    if not docker_client:
        raise HTTPException(status_code=503, detail="Docker client not available")
    
    try:
        container = docker_client.containers.get(container_id)
        container.stop(timeout=timeout)
        return {"message": f"Container {container_id} stopped successfully"}
    except docker.errors.NotFound:
        raise HTTPException(status_code=404, detail="Container not found")
    except Exception as e:
        logger.error(f"Error stopping container: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/containers/{container_id}/restart")
async def restart_container(container_id: str, timeout: int = 10):
    """Restart a container"""
    if not docker_client:
        raise HTTPException(status_code=503, detail="Docker client not available")
    
    try:
        container = docker_client.containers.get(container_id)
        container.restart(timeout=timeout)
        return {"message": f"Container {container_id} restarted successfully"}
    except docker.errors.NotFound:
        raise HTTPException(status_code=404, detail="Container not found")
    except Exception as e:
        logger.error(f"Error restarting container: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/containers/{container_id}/logs")
async def get_container_logs(container_id: str, tail: int = 100, follow: bool = False):
    """Get container logs"""
    if not docker_client:
        raise HTTPException(status_code=503, detail="Docker client not available")
    
    try:
        container = docker_client.containers.get(container_id)
        logs = container.logs(tail=tail, follow=follow, timestamps=True)
        return {"logs": logs.decode('utf-8')}
    except docker.errors.NotFound:
        raise HTTPException(status_code=404, detail="Container not found")
    except Exception as e:
        logger.error(f"Error getting container logs: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/images", response_model=List[ImageInfo])
async def list_images():
    """List Docker images"""
    if not docker_client:
        raise HTTPException(status_code=503, detail="Docker client not available")
    
    try:
        images = docker_client.images.list()
        result = []
        
        for image in images:
            result.append(ImageInfo(
                id=image.id.split(':')[1][:12],
                tags=image.tags,
                created=datetime.fromisoformat(image.attrs["Created"].replace("Z", "+00:00")),
                size=image.attrs["Size"],
                labels=image.labels or {}
            ))
        
        return result
    
    except Exception as e:
        logger.error(f"Error listing images: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/volumes", response_model=List[VolumeInfo])
async def list_volumes():
    """List Docker volumes"""
    if not docker_client:
        raise HTTPException(status_code=503, detail="Docker client not available")
    
    try:
        volumes = docker_client.volumes.list()
        result = []
        
        for volume in volumes:
            result.append(VolumeInfo(
                name=volume.name,
                driver=volume.attrs["Driver"],
                mountpoint=volume.attrs["Mountpoint"],
                created=datetime.fromisoformat(volume.attrs["CreatedAt"].replace("Z", "+00:00")),
                labels=volume.attrs.get("Labels") or {}
            ))
        
        return result
    
    except Exception as e:
        logger.error(f"Error listing volumes: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/networks", response_model=List[NetworkInfo])
async def list_networks():
    """List Docker networks"""
    if not docker_client:
        raise HTTPException(status_code=503, detail="Docker client not available")
    
    try:
        networks = docker_client.networks.list()
        result = []
        
        for network in networks:
            result.append(NetworkInfo(
                id=network.id[:12],
                name=network.name,
                driver=network.attrs["Driver"],
                scope=network.attrs["Scope"],
                created=datetime.fromisoformat(network.attrs["Created"].replace("Z", "+00:00")),
                labels=network.attrs.get("Labels") or {}
            ))
        
        return result
    
    except Exception as e:
        logger.error(f"Error listing networks: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/system/info")
async def get_system_info():
    """Get Docker system information"""
    if not docker_client:
        raise HTTPException(status_code=503, detail="Docker client not available")
    
    try:
        info = docker_client.info()
        return {
            "containers": info.get("Containers", 0),
            "containers_running": info.get("ContainersRunning", 0),
            "containers_paused": info.get("ContainersPaused", 0),
            "containers_stopped": info.get("ContainersStopped", 0),
            "images": info.get("Images", 0),
            "server_version": info.get("ServerVersion", "unknown"),
            "architecture": info.get("Architecture", "unknown"),
            "operating_system": info.get("OperatingSystem", "unknown"),
            "total_memory": info.get("MemTotal", 0),
            "cpu_count": info.get("NCPU", 0),
            "docker_root_dir": info.get("DockerRootDir", "unknown")
        }
    
    except Exception as e:
        logger.error(f"Error getting system info: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# MCP Protocol implementation
@app.post("/mcp/tools/call")
async def mcp_tool_call(request: Dict[str, Any]):
    """MCP tool call handler"""
    try:
        tool_name = request.get("name")
        arguments = request.get("arguments", {})
        
        if tool_name == "list_containers":
            all_containers = arguments.get("all", False)
            containers = await list_containers(all_containers)
            return {"result": {"containers": [c.dict() for c in containers]}}
        
        elif tool_name == "get_container":
            container_id = arguments.get("container_id")
            container = await get_container(container_id)
            return {"result": container}
        
        elif tool_name == "start_container":
            container_id = arguments.get("container_id")
            result = await start_container(container_id)
            return {"result": result}
        
        elif tool_name == "stop_container":
            container_id = arguments.get("container_id")
            timeout = arguments.get("timeout", 10)
            result = await stop_container(container_id, timeout)
            return {"result": result}
        
        elif tool_name == "get_container_logs":
            container_id = arguments.get("container_id")
            tail = arguments.get("tail", 100)
            logs = await get_container_logs(container_id, tail)
            return {"result": logs}
        
        elif tool_name == "list_images":
            images = await list_images()
            return {"result": {"images": [i.dict() for i in images]}}
        
        elif tool_name == "get_system_info":
            info = await get_system_info()
            return {"result": info}
        
        else:
            raise HTTPException(status_code=400, detail=f"Unknown tool: {tool_name}")
    
    except Exception as e:
        logger.error(f"MCP tool call error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/mcp/tools")
async def mcp_tools():
    """Get available MCP tools"""
    tools = [
        {
            "name": "list_containers",
            "description": "List Docker containers",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "all": {"type": "boolean", "description": "Include stopped containers"}
                }
            }
        },
        {
            "name": "get_container",
            "description": "Get detailed container information",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "container_id": {"type": "string", "description": "Container ID or name"}
                },
                "required": ["container_id"]
            }
        },
        {
            "name": "start_container",
            "description": "Start a Docker container",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "container_id": {"type": "string", "description": "Container ID or name"}
                },
                "required": ["container_id"]
            }
        },
        {
            "name": "stop_container",
            "description": "Stop a Docker container",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "container_id": {"type": "string", "description": "Container ID or name"},
                    "timeout": {"type": "integer", "description": "Stop timeout in seconds"}
                },
                "required": ["container_id"]
            }
        },
        {
            "name": "get_container_logs",
            "description": "Get container logs",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "container_id": {"type": "string", "description": "Container ID or name"},
                    "tail": {"type": "integer", "description": "Number of log lines to return"}
                },
                "required": ["container_id"]
            }
        },
        {
            "name": "list_images",
            "description": "List Docker images",
            "inputSchema": {
                "type": "object",
                "properties": {}
            }
        },
        {
            "name": "get_system_info",
            "description": "Get Docker system information",
            "inputSchema": {
                "type": "object",
                "properties": {}
            }
        }
    ]
    return {"tools": tools}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000, log_level="info")