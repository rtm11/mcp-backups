#!/usr/bin/env python3
"""
Brave Search MCP Server - Web search capabilities
"""

import os
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Brave Search MCP Server", version="1.0.0")

# Configuration
BRAVE_API_KEY = os.getenv('BRAVE_API_KEY')
BRAVE_API_URL = "https://api.search.brave.com/res/v1/web/search"
RATE_LIMIT = int(os.getenv('SEARCH_RATE_LIMIT', '10'))

class SearchRequest(BaseModel):
    query: str
    count: int = Field(default=10, le=20, description="Number of results (max 20)")
    offset: int = Field(default=0, ge=0, description="Search offset")
    country: str = Field(default="US", description="Country code")
    lang: str = Field(default="en", description="Language code")
    safesearch: str = Field(default="moderate", description="Safe search level")
    freshness: Optional[str] = Field(default=None, description="Freshness filter")

class SearchResult(BaseModel):
    title: str
    url: str
    description: str
    published: Optional[str] = None
    thumbnail: Optional[str] = None
    language: Optional[str] = None

class SearchResponse(BaseModel):
    query: str
    results: List[SearchResult]
    total_results: int
    search_time: float
    timestamp: datetime

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    api_configured = bool(BRAVE_API_KEY)
    
    return {
        "status": "healthy" if api_configured else "configuration_needed",
        "service": "Brave Search MCP Server",
        "timestamp": datetime.now().isoformat(),
        "api_configured": api_configured,
        "rate_limit": RATE_LIMIT
    }

@app.post("/search", response_model=SearchResponse)
async def search_web(request: SearchRequest):
    """Perform web search using Brave Search API"""
    if not BRAVE_API_KEY:
        raise HTTPException(status_code=503, detail="Brave Search API key not configured")
    
    start_time = datetime.now()
    
    try:
        headers = {
            "Accept": "application/json",
            "Accept-Encoding": "gzip",
            "X-Subscription-Token": BRAVE_API_KEY
        }
        
        params = {
            "q": request.query,
            "count": request.count,
            "offset": request.offset,
            "country": request.country,
            "lang": request.lang,
            "safesearch": request.safesearch
        }
        
        if request.freshness:
            params["freshness"] = request.freshness
        
        async with httpx.AsyncClient() as client:
            response = await client.get(BRAVE_API_URL, headers=headers, params=params)
            response.raise_for_status()
            
            data = response.json()
            search_time = (datetime.now() - start_time).total_seconds()
            
            # Parse results
            results = []
            web_results = data.get("web", {}).get("results", [])
            
            for result in web_results:
                search_result = SearchResult(
                    title=result.get("title", ""),
                    url=result.get("url", ""),
                    description=result.get("description", ""),
                    published=result.get("age"),
                    thumbnail=result.get("profile", {}).get("img") if result.get("profile") else None,
                    language=result.get("language")
                )
                results.append(search_result)
            
            return SearchResponse(
                query=request.query,
                results=results,
                total_results=len(results),
                search_time=search_time,
                timestamp=datetime.now()
            )
    
    except httpx.HTTPStatusError as e:
        logger.error(f"Brave Search API error: {e}")
        if e.response.status_code == 401:
            raise HTTPException(status_code=401, detail="Invalid API key")
        elif e.response.status_code == 429:
            raise HTTPException(status_code=429, detail="Rate limit exceeded")
        else:
            raise HTTPException(status_code=500, detail="Search API error")
    
    except Exception as e:
        logger.error(f"Search error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/search/suggestions")
async def get_suggestions(query: str):
    """Get search suggestions (mock implementation)"""
    # Note: Brave Search API doesn't provide suggestions endpoint
    # This is a mock implementation for demonstration
    suggestions = [
        f"{query} tutorial",
        f"{query} guide",
        f"{query} examples",
        f"best {query}",
        f"how to {query}"
    ]
    
    return {"query": query, "suggestions": suggestions[:5]}

@app.get("/search/news")
async def search_news(query: str, count: int = 10):
    """Search for news articles"""
    if not BRAVE_API_KEY:
        raise HTTPException(status_code=503, detail="Brave Search API key not configured")
    
    try:
        headers = {
            "Accept": "application/json",
            "Accept-Encoding": "gzip",
            "X-Subscription-Token": BRAVE_API_KEY
        }
        
        params = {
            "q": query,
            "count": count,
            "freshness": "pd"  # Past day for news
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.get(BRAVE_API_URL, headers=headers, params=params)
            response.raise_for_status()
            
            data = response.json()
            news_results = data.get("news", {}).get("results", [])
            
            results = []
            for result in news_results:
                results.append({
                    "title": result.get("title", ""),
                    "url": result.get("url", ""),
                    "description": result.get("description", ""),
                    "published": result.get("age"),
                    "source": result.get("profile", {}).get("name") if result.get("profile") else None
                })
            
            return {"query": query, "news": results, "count": len(results)}
    
    except Exception as e:
        logger.error(f"News search error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/search/images")
async def search_images(query: str, count: int = 10):
    """Search for images"""
    if not BRAVE_API_KEY:
        raise HTTPException(status_code=503, detail="Brave Search API key not configured")
    
    try:
        headers = {
            "Accept": "application/json",
            "Accept-Encoding": "gzip",
            "X-Subscription-Token": BRAVE_API_KEY
        }
        
        params = {
            "q": query,
            "count": count
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.get(BRAVE_API_URL, headers=headers, params=params)
            response.raise_for_status()
            
            data = response.json()
            image_results = data.get("images", {}).get("results", [])
            
            results = []
            for result in image_results:
                results.append({
                    "title": result.get("title", ""),
                    "url": result.get("url", ""),
                    "thumbnail": result.get("thumbnail", {}).get("src"),
                    "source": result.get("source"),
                    "properties": result.get("properties", {})
                })
            
            return {"query": query, "images": results, "count": len(results)}
    
    except Exception as e:
        logger.error(f"Image search error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# MCP Protocol implementation
@app.post("/mcp/tools/call")
async def mcp_tool_call(request: Dict[str, Any]):
    """MCP tool call handler"""
    try:
        tool_name = request.get("name")
        arguments = request.get("arguments", {})
        
        if tool_name == "web_search":
            search_req = SearchRequest(**arguments)
            result = await search_web(search_req)
            return {"result": result.dict()}
        
        elif tool_name == "news_search":
            query = arguments.get("query")
            count = arguments.get("count", 10)
            result = await search_news(query, count)
            return {"result": result}
        
        elif tool_name == "image_search":
            query = arguments.get("query")
            count = arguments.get("count", 10)
            result = await search_images(query, count)
            return {"result": result}
        
        elif tool_name == "get_suggestions":
            query = arguments.get("query")
            result = await get_suggestions(query)
            return {"result": result}
        
        else:
            raise HTTPException(status_code=400, detail=f"Unknown tool: {tool_name}")
    
    except Exception as e:
        logger.error(f"MCP tool call error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/mcp/tools")
async def mcp_tools():
    """Get available MCP tools"""
    tools = [
        {
            "name": "web_search",
            "description": "Search the web using Brave Search",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"},
                    "count": {"type": "integer", "description": "Number of results (max 20)"},
                    "country": {"type": "string", "description": "Country code"},
                    "lang": {"type": "string", "description": "Language code"},
                    "safesearch": {"type": "string", "description": "Safe search level"},
                    "freshness": {"type": "string", "description": "Freshness filter"}
                },
                "required": ["query"]
            }
        },
        {
            "name": "news_search",
            "description": "Search for news articles",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"},
                    "count": {"type": "integer", "description": "Number of results"}
                },
                "required": ["query"]
            }
        },
        {
            "name": "image_search",
            "description": "Search for images",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Search query"},
                    "count": {"type": "integer", "description": "Number of results"}
                },
                "required": ["query"]
            }
        },
        {
            "name": "get_suggestions",
            "description": "Get search suggestions for a query",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {"type": "string", "description": "Query for suggestions"}
                },
                "required": ["query"]
            }
        }
    ]
    return {"tools": tools}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=3000, log_level="info")